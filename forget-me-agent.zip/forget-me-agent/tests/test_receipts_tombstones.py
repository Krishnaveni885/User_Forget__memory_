import json, copy
from conftest import build_hub
from forgetme.config import ForgetConfig
from forgetme.pipeline import ForgetMe
from forgetme.receipts import ReceiptLog, verify_chain, verify_commitment
from forgetme.tombstones import AuditVault


def run(style, scope="all", n=2):
    cfg = ForgetConfig(tombstone_style=style, tombstone_scope=scope)
    hub = build_hub(["diabetes", "veg", "hyderabad"], cfg=cfg)
    fm = ForgetMe(hub, cfg)
    reps = [fm.forget("Forget that I have diabetes")]
    return hub, fm, reps


def test_receipt_chain_tamper_and_signature():
    hub = build_hub(["diabetes", "veg", "hyderabad", "salary"])
    fm = ForgetMe(hub)
    fm.forget("Forget that I have diabetes")
    fm.forget("Forget my salary")
    fm.forget("Forget that I live in Hyderabad")
    rs = fm.receipts.receipts
    assert len(rs) == 3 and rs[1]["prev_hash"] == rs[0]["receipt_hash"]
    assert verify_chain(rs, fm.receipts.public_key_pem)[0]
    bad = copy.deepcopy(rs); bad[1]["counts"]["purged"] = 0
    ok, idx, why = verify_chain(bad)
    assert not ok and idx == 1
    bad = copy.deepcopy(rs); del bad[1]
    assert not verify_chain(bad)[0]                                  # deleting a receipt breaks the chain
    bad = copy.deepcopy(rs); bad[2]["signature"] = "00" * 64
    assert not verify_chain(bad, fm.receipts.public_key_pem)[0]


def test_receipt_contains_no_deleted_content():
    hub = build_hub(["diabetes", "veg"])
    fm = ForgetMe(hub)
    fm.forget("Forget that I have diabetes")
    blob = json.dumps(fm.receipts.receipts).lower()
    for leak in ["diabet", "sugar", "type 2", "forget that"]:
        assert leak not in blob
    r = fm.receipts.receipts[0]
    desc = "factual|['diabetes']|[]|['health']|None"
    assert verify_commitment(fm.receipts.hmac_key, r, desc)          # key holder can check the target
    assert not verify_commitment(fm.receipts.hmac_key, r, "factual|['asthma']|[]|['health']|None")


def test_tombstone_styles_leave_different_traces():
    hub, fm, _ = run("descriptive")
    marks = [m.text for m in hub.store.all(("tombstone",))]
    assert marks and all("medical condition" in t for t in marks)    # descriptive marker leaks the category
    hub, fm, _ = run("generic")
    assert all(m.text == "[removed]" for m in hub.store.all(("tombstone",)))
    hub, fm, _ = run("none")
    assert not hub.store.all(("tombstone",))
    hub, fm, _ = run("encrypted_log")
    assert not hub.store.all(("tombstone",)) and fm.vault.records
    assert "medical condition" not in " ".join(m.text for m in hub.store.all(("live", "tombstone")))
    assert fm.vault.decrypt_all()[0]["labels"] == ["medical condition"]
    assert b"medical condition" not in b"".join(fm.vault.records)    # ciphertext only
    other = AuditVault()
    try:
        other.records = fm.vault.records; other.decrypt_all(); raise AssertionError("wrong key must fail")
    except Exception as e:
        assert "AssertionError" not in type(e).__name__


def test_compaction_removes_id_gaps():
    cfg = ForgetConfig(compact_ids=True)
    hub = build_hub(["diabetes", "veg", "hyderabad"], cfg=cfg)
    ForgetMe(hub, cfg).forget("Forget that I have diabetes")
    ids = sorted(hub.store.ids(("live",)))
    assert ids == list(range(1, len(ids) + 1)) and set(hub.index.ids) == set(ids)
    assert hub.agent("A").answer("What is my dietary preference?").text.lower().count("vegetarian") >= 1
