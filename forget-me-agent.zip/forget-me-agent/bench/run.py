"""Run all experiments:  python -m bench.run --n 60 --seeds 0 1 2 --out results
Writes CSVs, PNG charts and results/RESULTS.md (auto-generated; numbers come only from these runs)."""
from __future__ import annotations

import argparse
import json
import os
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor

import numpy as np
import pandas as pd

from .metrics import aggregate, bootstrap_ci, run_instance
from .synth import generate_dataset
from .systems import ALL, BASELINES, ABLATIONS

KEYS = ["RA", "FE", "PR", "RLA", "AR", "RPR", "Score", "Leakage", "ForgetSuccess", "OverForget"]


def _job(args):
    name, seed, n, profile, edge_drop = args
    ds = generate_dataset(n, seed)
    rows, agg_cost = [], defaultdict(float)
    for inst in ds:
        r, c = run_instance(ALL[name], inst, seed, profile, edge_drop)
        rows += r
        for k, v in c.items():
            agg_cost[k] += v
    return name, seed, profile, edge_drop, rows, dict(agg_cost)


def run_grid(names, seeds, n, profile="lenient", edge_drop=0.0, workers=8):
    jobs = [(nm, s, n, profile, edge_drop) for nm in names for s in seeds]
    out = defaultdict(lambda: {"rows": [], "cost": defaultdict(float), "per_seed": []})
    with ProcessPoolExecutor(workers) as ex:
        for name, seed, prof, ed, rows, cost in ex.map(_job, jobs):
            o = out[name]
            o["rows"] += rows
            for k, v in cost.items():
                o["cost"][k] += v
            o["per_seed"].append(aggregate(rows))
    return out


def fmt(x, d=1):
    return "–" if x != x else f"{x:.{d}f}"


def md_table(df: pd.DataFrame) -> str:
    cols = list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join("---" for _ in cols) + "|"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(str(r[c]) for c in cols) + " |")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=60)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--out", default="results")
    ap.add_argument("--workers", type=int, default=8)
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    names = list(ALL)
    md = ["# Results (auto-generated)\n",
          f"Offline deterministic backend; synthetic extension set: {a.n} instances x seeds {a.seeds}. "
          "**These numbers measure the architecture on a lexicon-generated benchmark, not LLM behaviour and not the "
          "public BEMULA benchmark.** See docs/LIMITATIONS.md.\n"]

    # ---------------- E1/E2: main comparison + ablations, two answerer profiles
    summary = {}
    for profile in ("lenient", "strict"):
        res = run_grid(names, a.seeds, a.n, profile, 0.0, a.workers)
        summary[profile] = res
        recs = []
        for nm in names:
            o = res[nm]
            ps = pd.DataFrame(o["per_seed"])
            ci = bootstrap_ci(o["rows"], n_boot=200)
            n_f = max(o["cost"]["n"], 1)
            row = {"System": nm}
            for k in ["FE", "AR", "PR", "RLA", "RPR", "Score"]:
                row[k] = f"{ps[k].mean():.1f}±{ps[k].std(ddof=0):.1f}"
            row["Score 95% CI"] = f"[{ci['Score'][0]:.1f}, {ci['Score'][1]:.1f}]"
            row["Leakage%"] = fmt(ps["Leakage"].mean())
            row["Residual lineage"] = f"{o['cost']['residual']:.0f}/{o['cost']['target_lineage']:.0f}"
            row["Collateral"] = f"{o['cost']['collateral']:.0f}/{o['cost']['unrelated']:.0f}"
            row["s/forget"] = f"{o['cost']['seconds'] / n_f:.4f}"
            row["tok/forget"] = f"{o['cost']['tokens'] / n_f:.0f}"
            recs.append(row)
        df = pd.DataFrame(recs)
        df.to_csv(f"{a.out}/main_{profile}.csv", index=False)
        md += [f"\n## Main comparison and ablations — answerer profile `{profile}`\n",
               "Mean±std over seeds (percent). Leakage = share of efficacy+attack probes revealing the target "
               "(lineage oracle). Residual lineage = live memories still descending from a target fact. "
               "Collateral = unrelated memories lost.\n", md_table(df)]
        pd.DataFrame([{**{"system": nm}, **aggregate(res[nm]["rows"])} for nm in names]).to_csv(
            f"{a.out}/main_{profile}_pooled.csv", index=False)

    # ---------------- E3: by request type and extension slices (lenient)
    res = summary["lenient"]
    focus = ["NoDeletion", "DeleteByID", "SBUStyle(sim)", "ForgetMe-noGraph", "ForgetMe-noCrossAgent", "ForgetMe-full"]
    recs = []
    for nm in focus:
        rows = res[nm]["rows"]
        d = {"System": nm}
        for k in ["F1", "F2", "F3", "F4", "F5", "F6"]:
            sub = [r for r in rows if r["rkind"] == k and r["suite"] in ("efficacy", "attack") and r["c"] == 1]
            d[k] = fmt(100 * (1 - np.mean([r["leak"] for r in sub]))) if sub else "–"
        recs.append(d)
    t_type = pd.DataFrame(recs); t_type.to_csv(f"{a.out}/by_type.csv", index=False)
    md += ["\n## Non-leak rate by request type (higher is better; efficacy+attack items)\n", md_table(t_type)]
    recs = []
    for nm in focus:
        rows = res[nm]["rows"]
        d = {"System": nm}
        for label, f in [("single-agent", lambda r: not r["multi"]), ("multi-agent", lambda r: r["multi"]),
                         ("depth 1", lambda r: r["depth"] == 1), ("depth 3", lambda r: r["depth"] == 3),
                         ("English", lambda r: not r["codemix"]), ("code-mixed", lambda r: r["codemix"])]:
            sub = [r for r in rows if r["suite"] in ("efficacy", "attack") and r["c"] == 1 and f(r)]
            d[label] = fmt(100 * (1 - np.mean([r["leak"] for r in sub]))) if sub else "–"
        recs.append(d)
    t_slice = pd.DataFrame(recs); t_slice.to_csv(f"{a.out}/by_slice.csv", index=False)
    md += ["\n## Non-leak rate on extension slices (the cases BEMULA does not cover)\n", md_table(t_slice)]

    # ---------------- E4: incomplete provenance sweep
    sweep = []
    for p in [0.0, 0.1, 0.3, 0.5, 0.8]:
        for nm in ["ForgetMe-full", "ForgetMe-noRepair", "ForgetMe-noGuard", "ForgetMe-noGraph"]:
            r = run_grid([nm], a.seeds[:2], max(a.n // 2, 20), "lenient", p, a.workers)[nm]
            ag = aggregate(r["rows"])
            sweep.append({"edge_drop": p, "System": nm, "Leakage%": ag["Leakage"], "AR": ag["AR"], "Score": ag["Score"],
                          "Residual lineage": f"{r['cost']['residual']:.0f}/{r['cost']['target_lineage']:.0f}",
                          "resid_frac": r["cost"]["residual"] / max(r["cost"]["target_lineage"], 1)})
    sw = pd.DataFrame(sweep); sw.to_csv(f"{a.out}/provenance_noise.csv", index=False)
    show = sw.copy()
    for c in ["Leakage%", "AR", "Score"]:
        show[c] = show[c].map(lambda x: fmt(x))
    show["resid_frac"] = show["resid_frac"].map(lambda x: f"{100 * x:.1f}%")
    md += ["\n## Robustness to incomplete provenance (fraction of edges dropped)\n", md_table(show)]

    # ---------------- charts
    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        pooled = pd.read_csv(f"{a.out}/main_lenient_pooled.csv")
        fig, ax = plt.subplots(figsize=(9, 4.2))
        x = np.arange(len(pooled)); w = 0.27
        ax.bar(x - w, pooled["FE"], w, label="Efficacy (FE)"); ax.bar(x, pooled["AR"], w, label="Attack robustness (AR)")
        ax.bar(x + w, pooled["Score"], w, label="BEMULA-style Score")
        ax.set_xticks(x); ax.set_xticklabels(pooled["system"], rotation=35, ha="right", fontsize=8); ax.set_ylabel("%")
        ax.legend(fontsize=8); ax.set_title("Forgetting quality by system (offline backend, synthetic set)")
        fig.tight_layout(); fig.savefig(f"{a.out}/fig_main.png", dpi=140); plt.close(fig)
        fig, ax = plt.subplots(figsize=(5.5, 4.5))
        for _, r in pooled.iterrows():
            ax.scatter(r["FE"], r["PR"], s=45); ax.annotate(r["system"], (r["FE"], r["PR"]), fontsize=6, xytext=(3, 3), textcoords="offset points")
        ax.set_xlabel("Forgetting efficacy FE (%)"); ax.set_ylabel("Preservation PR (%)"); ax.set_title("FE vs PR trade-off")
        ax.set_xlim(0, 105); ax.set_ylim(0, 105); fig.tight_layout(); fig.savefig(f"{a.out}/fig_fe_pr.png", dpi=140); plt.close(fig)
        fig, ax = plt.subplots(figsize=(6, 4))
        for nm, g in sw.groupby("System"):
            ax.plot(g["edge_drop"], 100 * g["resid_frac"], marker="o", label=nm)
        ax.set_xlabel("fraction of provenance edges dropped"); ax.set_ylabel("residual target lineage (%)")
        ax.legend(fontsize=8); ax.set_title("Robustness to incomplete provenance"); fig.tight_layout()
        fig.savefig(f"{a.out}/fig_noise.png", dpi=140); plt.close(fig)
    except Exception as e:  # pragma: no cover
        md.append(f"\n(charts skipped: {e})")

    # ---------------- E5/E6: tombstone study and judge check
    from .tombstone_study import run_study, study_markdown
    ts = run_study(trials=400, seed=0)
    ts.to_csv(f"{a.out}/tombstone_study.csv", index=False)
    md += ["\n## Tombstone leakage study\n", study_markdown(ts)]
    try:
        from .judge_validation import judge_report
        md += ["\n## Judge reliability (self-check, not a human study)\n", judge_report(a.out)]
    except Exception as e:  # pragma: no cover
        md.append(f"\n(judge check failed: {e})")
    with open(f"{a.out}/RESULTS.md", "w") as f:
        f.write("\n".join(md) + "\n")
    print("\n".join(md))


if __name__ == "__main__":
    main()
