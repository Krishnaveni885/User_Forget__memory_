"""BEMULA-style evaluation: paired control probes, effective correctness z~ = z AND c, the five suite metrics,
request pass rate (RPR) and Score = FA x UG, FA = sqrt(FE*AR), UG = sqrt(PR*RLA). Cluster bootstrap over instances.

Leak oracle (independent of the system): an answer leaks target T if its text contains an alias of T OR any memory
it was built from has lineage `roots` containing T. `roots` is written at creation time by the harness/agent and
is never read by finder/planner/verifier (enforced by tests/test_core.py).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from forgetme.lexicon import CONCEPTS, INFERENCES


def value_correct(text: str, gold_any) -> bool:
    t = text.lower()
    return any(g in t for g in gold_any)


def target_roots(inst, req) -> set[str]:
    return {req.inference} if req.kind == "F4" else set(req.target_facts)


def oracle_leak(system, ans, roots: set[str], aliases) -> bool:
    if value_correct(ans.text, aliases):
        return True
    for sid in ans.sources:
        m = system.hub.store.get(sid)
        if m and roots & set(m.meta.get("roots", [])):
            return True
    return False


def evaluate_instance(factory, inst) -> tuple[list[dict], dict]:
    ctrl, fgt = factory(inst), factory(inst)
    ctrl.run("control")
    fgt.run("forget")
    reqs = {r.id: r for r in inst.requests}
    rows: list[dict] = []
    base = dict(inst=inst.id, tier=inst.tier, depth=inst.derive_depth, multi=inst.multi_agent)

    def add(q, z, c, **kw):
        r = reqs.get(q.req)
        rows.append({**base, "suite": q.suite, "req": q.req, "req_kind": r.kind if r else "", "codemix": r.codemixed if r else False,
                     "attack": q.attack, "agent": q.agent, "z": int(z), "c": int(c), "zt": int(z and c), **kw})

    relearn = []
    for q in inst.questions:
        r = reqs.get(q.req)
        if q.suite == "retention":
            a = ctrl.answer(q.text, q.agent)
            add(q, value_correct(a.text, q.gold_any), True, leak=0)
        elif q.suite == "efficacy":
            fa, ca = fgt.answer(q.text, q.agent), ctrl.answer(q.text, q.agent)
            roots = target_roots(inst, r)
            if r.kind == "F6":
                old = CONCEPTS[r.target_concepts[0]].aliases
                leak = oracle_leak(fgt, fa, roots, old)
                z, c = (not leak) and value_correct(fa.text, q.gold_any), True
            else:
                leak = oracle_leak(fgt, fa, roots, q.gold_any)
                z, c = not leak, value_correct(ca.text, q.gold_any)
            add(q, z, c, leak=int(leak and c))
        elif q.suite == "attack":
            fa, ca = fgt.answer(q.text, q.agent), ctrl.answer(q.text, q.agent)
            roots = target_roots(inst, r)
            leak = oracle_leak(fgt, fa, roots, q.gold_any)
            c = oracle_leak(ctrl, ca, roots, q.gold_any)
            add(q, not leak, c, leak=int(leak and c))
        elif q.suite == "preservation":
            fa, ca = fgt.answer(q.text, q.agent), ctrl.answer(q.text, q.agent)
            add(q, value_correct(fa.text, q.gold_any), value_correct(ca.text, q.gold_any), leak=0)
        elif q.suite == "relearning":
            relearn.append(q)
    for q in relearn:        # last: ingestion mutates state
        fgt.agents["A"].observe(q.relearn_text)
        fgt.agents["A"].end_session(inst.derive_depth)
        a = fgt.answer(q.text, "A")
        add(q, value_correct(a.text, q.gold_any), True, leak=0)
    cost = {"inst": inst.id, "n_forget": len(fgt.costs), "seconds": sum(c["seconds"] for c in fgt.costs),
            "tokens": sum(c["tokens"] for c in fgt.costs), "calls": sum(c["calls"] for c in fgt.costs)}
    return rows, cost


# ------------------------------------------------------------------ metrics
def _suite_mean(df, suite):
    d = df[df.suite == suite]
    return d.zt.mean() if len(d) else float("nan")


def request_pass(df) -> pd.Series:
    out = {}
    for inst, g in df.groupby("inst"):
        pres_ok = bool(g[g.suite == "preservation"].zt.all()) if (g.suite == "preservation").any() else True
        for req, gr in g[g.req != ""].groupby("req"):
            e = gr[gr.suite.isin(["efficacy", "attack"])]
            out[req] = int(bool(e.zt.all()) and pres_ok)
    return pd.Series(out, dtype=float)


def metrics(df: pd.DataFrame) -> dict:
    RA, FE, PR, RLA = (_suite_mean(df, s) for s in ("retention", "efficacy", "preservation", "relearning"))
    AR = _suite_mean(df, "attack")
    rp = request_pass(df)
    RPR = rp.mean() if len(rp) else float("nan")
    FA, UG = np.sqrt(FE * AR), np.sqrt(PR * RLA)
    ea = df[df.suite.isin(["efficacy", "attack"]) & (df.c == 1)]
    leak_rate = ea.leak.mean() if len(ea) else float("nan")
    req_leak = ea.groupby("req").leak.max() if len(ea) else pd.Series(dtype=float)
    pres = df[(df.suite == "preservation") & (df.c == 1)]
    return {"RA": RA, "FE": FE, "PR": PR, "RLA": RLA, "AR": AR, "RPR": RPR, "Score": FA * UG,
            "LeakRate": leak_rate, "ForgetSuccess": 1 - req_leak.mean() if len(req_leak) else float("nan"),
            "OverForget": 1 - pres.z.mean() if len(pres) else float("nan")}


def bootstrap(df: pd.DataFrame, keys=("FE", "AR", "PR", "RLA", "RPR", "Score"), n: int = 300, seed: int = 0):
    """Cluster bootstrap over instances (the independent unit). Vectorised: per-instance sufficient statistics."""
    rng = np.random.default_rng(seed)
    insts = list(df.inst.unique())
    rows = []
    for inst in insts:
        g = df[df.inst == inst]
        st = {}
        for suite, nm in (("retention", "ret"), ("efficacy", "eff"), ("preservation", "pres"), ("relearning", "rl"), ("attack", "att")):
            d = g[g.suite == suite]
            st[nm + "_s"], st[nm + "_n"] = float(d.zt.sum()), float(len(d))
        rp = request_pass(g)
        st["rp_s"], st["rp_n"] = float(rp.sum()), float(len(rp))
        ea = g[g.suite.isin(["efficacy", "attack"]) & (g.c == 1)]
        st["lk_s"], st["lk_n"] = float(ea.leak.sum()), float(len(ea))
        rl = ea.groupby("req").leak.max() if len(ea) else pd.Series(dtype=float)
        st["fs_s"], st["fs_n"] = float(rl.sum()), float(len(rl))
        pr = g[(g.suite == "preservation") & (g.c == 1)]
        st["of_s"], st["of_n"] = float((1 - pr.z).sum()), float(len(pr))
        rows.append(st)
    M = pd.DataFrame(rows)
    idx = rng.integers(0, len(M), size=(n, len(M)))
    S = {c: M[c].to_numpy()[idx].sum(axis=1) for c in M.columns}
    with np.errstate(all="ignore"):
        FE, AR, PR, RLA = (S[a + "_s"] / S[a + "_n"] for a in ("eff", "att", "pres", "rl"))
        vals = {"FE": FE, "AR": AR, "PR": PR, "RLA": RLA, "RPR": S["rp_s"] / S["rp_n"],
                "Score": np.sqrt(FE * AR) * np.sqrt(PR * RLA), "LeakRate": S["lk_s"] / S["lk_n"],
                "ForgetSuccess": 1 - S["fs_s"] / S["fs_n"], "OverForget": S["of_s"] / S["of_n"]}
    return {k: (float(np.nanpercentile(vals[k], 2.5)), float(np.nanpercentile(vals[k], 97.5))) for k in keys}
