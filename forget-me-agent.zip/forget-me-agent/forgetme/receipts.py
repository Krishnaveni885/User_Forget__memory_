"""Step 11: hash-chained, content-free audit receipts (+ optional Ed25519 signature).

A receipt proves *that* an erasure was performed and *what the verifier measured*, without containing
the deleted content. Target and id lists are committed with HMAC under a key held by the data subject /
auditor (not stored with the receipts), so a receipt cannot be dictionary-attacked by whoever holds the log.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
import uuid

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

GENESIS = "0" * 64


def _canon(d: dict) -> bytes:
    return json.dumps(d, sort_keys=True, separators=(",", ":")).encode()


def _hmac(key: bytes, s: str) -> str:
    return hmac.new(key, s.encode(), hashlib.sha256).hexdigest()


def merkle_root(leaves: list[str]) -> str:
    if not leaves:
        return hashlib.sha256(b"").hexdigest()
    level = [hashlib.sha256(x.encode()).digest() for x in sorted(leaves)]
    while len(level) > 1:
        if len(level) % 2:
            level.append(level[-1])
        level = [hashlib.sha256(level[i] + level[i + 1]).digest() for i in range(0, len(level), 2)]
    return level[0].hex()


def state_digest(store, key: bytes) -> str:
    """Merkle root over live memories as HMAC(key, id|text): lets a key holder check the live state."""
    return merkle_root([_hmac(key, f"{m.id}|{m.text}") for m in store.all(("live", "tombstone"))])


class ReceiptLog:
    def __init__(self, path: str | None = None, hmac_key: bytes | None = None, signing_key: Ed25519PrivateKey | None = None):
        self.path = path
        self.hmac_key = hmac_key or os.urandom(32)
        self.signing_key = signing_key or Ed25519PrivateKey.generate()
        self.receipts: list[dict] = []
        if path and os.path.exists(path):
            with open(path) as f:
                self.receipts = [json.loads(l) for l in f if l.strip()]

    @property
    def public_key_pem(self) -> bytes:
        return self.signing_key.public_key().public_bytes(serialization.Encoding.PEM,
                                                           serialization.PublicFormat.SubjectPublicKeyInfo)

    def write_receipt(self, *, request_text: str, target_desc: str, plan_counts: dict, executed_ids: list[int],
                      verification: dict, rounds: int, tombstone_style: str, state_before: str, state_after: str,
                      config: dict, request_id: str | None = None) -> dict:
        prev = self.receipts[-1]["receipt_hash"] if self.receipts else GENESIS
        body = {
            "version": 1,
            "request_id": request_id or str(uuid.uuid4()),
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "prev_hash": prev,
            "request_commitment": _hmac(self.hmac_key, "req|" + request_text.strip().lower()),
            "target_commitment": _hmac(self.hmac_key, "tgt|" + target_desc),
            "counts": plan_counts,
            "affected_ids_root": merkle_root([_hmac(self.hmac_key, f"id|{i}") for i in executed_ids]),
            "verification": verification,
            "repair_rounds": rounds,
            "tombstone_style": tombstone_style,
            "state_digest_before": state_before,
            "state_digest_after": state_after,
            "config": config,
        }
        body["receipt_hash"] = hashlib.sha256(_canon(body)).hexdigest()
        body["signature"] = self.signing_key.sign(body["receipt_hash"].encode()).hex()
        self.receipts.append(body)
        if self.path:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
            with open(self.path, "a") as f:
                f.write(json.dumps(body, sort_keys=True) + "\n")
        return body


def verify_chain(receipts: list[dict], public_key_pem: bytes | None = None) -> tuple[bool, int | None, str]:
    """Return (ok, index_of_first_bad_receipt, reason)."""
    prev = GENESIS
    pub = serialization.load_pem_public_key(public_key_pem) if public_key_pem else None
    for i, r in enumerate(receipts):
        body = {k: v for k, v in r.items() if k not in ("receipt_hash", "signature")}
        if r.get("prev_hash") != prev:
            return False, i, "broken chain link (prev_hash)"
        if hashlib.sha256(_canon(body)).hexdigest() != r.get("receipt_hash"):
            return False, i, "receipt content was modified"
        if pub is not None:
            try:
                pub.verify(bytes.fromhex(r["signature"]), r["receipt_hash"].encode())
            except Exception:
                return False, i, "bad signature"
        prev = r["receipt_hash"]
    return True, None, "ok"


def verify_commitment(key: bytes, receipt: dict, target_desc: str) -> bool:
    """A key holder who knows the target can check the receipt refers to it."""
    return hmac.compare_digest(receipt["target_commitment"], _hmac(key, "tgt|" + target_desc))
