# Forget-Me Agent: verifiable erasure for AI agent memory

When a user says *"forget that I have diabetes"*, most agent-memory systems delete one entry while the same fact survives in
**summaries, derived notes, vector-index embeddings, caches, and memory shared with other agents**. This project is a drop-in layer that

1. **tracks provenance** (a DAG: every memory records its parents and the agent that wrote it),
2. **deletes the target and everything derived from it** (purge / re-derive / tombstone, chosen per memory so unrelated facts survive),
3. **tests whether the fact can still be recovered** (five probe styles + a control agent) and **repairs** if it can, and
4. writes a **hash-chained audit receipt** that proves the erasure without containing the deleted data.

> Status: complete, tested **offline prototype** + synthetic benchmark. It has **not** been run against a live LLM or the real BEMULA benchmark.
> Read [docs/LIMITATIONS.md](docs/LIMITATIONS.md) before quoting any number.

## Quick start
```bash
pip install -r requirements.txt
make test        # 28 tests
make example     # the worked example from the guide (section 5)
make ui          # Streamlit demo (provenance graph, forget box, receipts)   | make api -> FastAPI
make bench       # full experiments -> results/RESULTS.md and figures (about 15 minutes on 2 cores)
```
```python
from forgetme.agent import MemoryHub
from forgetme.pipeline import ForgetMe
hub = MemoryHub(); a = hub.agent("A")
a.observe("I was diagnosed with type 2 diabetes last year."); a.observe("I'm vegetarian, so no meat please."); a.end_session()
report = ForgetMe(hub).forget("Forget that I have diabetes")
print(report.deleted, report.rewritten, report.kept, report.leak_test, report.receipt_hash)
```

## Architecture (guide section 6 -> code)
| Step | Module | What it does |
|---|---|---|
| 1 Baseline 3-tier agent | `forgetme/agent.py`, `store.py`, `vector_index.py` | raw / summary / derived tiers in SQLite + a NumPy vector index with real per-vector deletes |
| 2 Provenance | `provenance.py` | NetworkX DAG; closure crosses agents via cross-agent edges |
| 3 Parse | `llm.py`, `models.py` | request -> validated `ParsedRequest` (F1-F6, code-mixed, clarifying question when vague) |
| 4 Find | `finder.py` | embedding candidates + judge ("contains or implies"), then closure |
| 5 Plan | `planner.py` | purge / re-derive / tombstone per node (a mixed summary is rewritten, not deleted) |
| 6 Execute | `executor.py` | DB rows (+ `VACUUM`, `secure_delete`), vector index, caches, conversation context, notify all agents |
| 7 Guard | `guard.py` | read-time blocklist: ids + HMAC'd token signatures (no plaintext of the deleted fact is stored) |
| 8-9 Verify + repair | `verifier.py`, `pipeline.py` | direct / indirect / inference / adversarial / tool-and-cross-agent probes, control agent for false positives, physical byte scan, leak-source tracing, re-plan loop |
| 10 Tombstones | `tombstones.py`, `bench/tombstone_study.py` | none / descriptive / generic / encrypted-log (+ id compaction), attacker study |
| 11 Receipts | `receipts.py` | hash chain + Ed25519 signature + HMAC commitments; contains no deleted content |
| 12 Benchmark | `bench/` | BEMULA-style paired forget/control extension set, BEMULA metrics, baselines, ablations |
| 13 Demo | `app/`, `forgetme/demo.py` | FastAPI + Streamlit |

Beyond the guide: stale-cache invalidation, suppression of re-derived inferences (F4), id compaction to hide deletion gaps, and a `NoisyJudgeBackend` (available in `llm.py`; not used in the reported experiments).

## Repository map
`forgetme/` library · `bench/` benchmark + experiments · `app/` demo · `tests/` 28 tests · `results/` generated tables/figures · `docs/` scope, limitations, runbook, paper outline.

## Headline results (offline backend, synthetic set, 60 instances x 3 seeds; see results/RESULTS.md)
| System | FE | AR | Leakage % | Residual target lineage | Score |
|---|---|---|---|---|---|
| NoDeletion | 7.3 | 0.0 | 98.4 | 5433/5405 | 0.0 |
| DeleteByID | 59.6 | 47.1 | 47.1 | 3096/5405 | 53.0 |
| SBUStyle(sim) | 73.7 | 64.4 | 29.3 | 1568/5405 | 68.9 |
| ForgetMe-noGraph | 78.0 | 68.7 | 23.9 | 2134/5405 | 73.2 |
| ForgetMe-noCrossAgent | 82.7 | 71.3 | 21.3 | 1588/5405 | 76.8 |
| **ForgetMe-full** | **96.0** | **91.7** | **0.5** | **0/5405** | **93.8** |

Takeaways that hold on this benchmark: provenance closure and cross-agent closure each matter (removing either leaves 20-24% of probes leaking);
descriptive tombstones let an attacker name the deleted category 100% of the time, generic markers do not, and an encrypted log plus id compaction brings the attacker to chance.
**Negative result:** the guard and the repair loop show no measurable benefit here (see LIMITATIONS 6). PR/RLA are not discriminating (LIMITATIONS 13).
These are not BEMULA numbers and not LLM results.

## Responsible use
Synthetic data only; never put real personal or medical data in the benchmark. This is technical guidance, not legal advice or a compliance claim
(check the DPDP Act 2023 / Rules 2025 text at meity.gov.in).
