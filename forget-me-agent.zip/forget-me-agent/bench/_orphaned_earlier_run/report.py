"""Charts + RESULTS.md from the CSVs written by bench.run."""
from __future__ import annotations

import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

PAL = ["#4C78A8", "#F58518", "#54A24B", "#E45756", "#72B7B2", "#B279A2", "#9D755D", "#BAB0AC"]


def md(df: pd.DataFrame, floatfmt=1) -> str:
    cols = [df.index.name or "system"] + list(df.columns)
    lines = ["| " + " | ".join(cols) + " |", "|" + "|".join(["---"] * len(cols)) + "|"]
    for idx, r in df.iterrows():
        cells = [str(idx)] + [(f"{v:.{floatfmt}f}" if isinstance(v, float) else str(v)) for v in r]
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def _bar(ax, df, cols, title, ylabel="%"):
    w = 0.8 / len(cols)
    for k, c in enumerate(cols):
        ax.bar([i + k * w for i in range(len(df))], df[c], w, label=c, color=PAL[k])
    ax.set_xticks([i + 0.4 - w / 2 for i in range(len(df))])
    ax.set_xticklabels([s.replace("(sim)", "\n(sim)") for s in df.index], rotation=30, ha="right", fontsize=8)
    ax.set_title(title, fontsize=10); ax.set_ylabel(ylabel); ax.legend(fontsize=8, frameon=False)
    ax.spines[["top", "right"]].set_visible(False)


def make_report(out: str, meta: dict):
    r = lambda n: pd.read_csv(f"{out}/{n}.csv", index_col=0)
    e1, e2, e4, e5 = r("E1_main"), r("E2_ablations"), r("E4_provenance_noise"), r("E5_answerer_profiles")
    e3 = pd.read_csv(f"{out}/E3_slices.csv"); e7 = pd.read_csv(f"{out}/E7_tombstone_study.csv")
    e6 = pd.read_csv(f"{out}/E6_parse_accuracy.csv", index_col=0); e6c = pd.read_csv(f"{out}/E6_parse_accuracy_codemix.csv", index_col=0)

    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    _bar(ax[0], e1, ["Score", "FE", "AR", "RPR"], "BEMULA-style metrics (higher is better)")
    _bar(ax[1], e1, ["Leakage", "OverForget"], "Leakage and over-forgetting (lower is better)")
    plt.tight_layout(); plt.savefig(f"{out}/fig1_main.png", dpi=150); plt.close()

    fig, ax = plt.subplots(figsize=(6, 4.5))
    for k, (s, row) in enumerate(e1.iterrows()):
        ax.scatter(row.Coverage, 100 - row.Leakage, s=70, color=PAL[k % 8], label=s)
    ax.set_xlabel("Unrelated-memory coverage kept (%)"); ax.set_ylabel("Forgotten: 100 - leakage (%)")
    ax.set_title("Forgetting vs preservation trade-off\\n(top-right is best)".replace("\\n", "\n"), fontsize=10)
    ax.legend(fontsize=7, frameon=False, loc="lower left"); ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout(); plt.savefig(f"{out}/fig2_tradeoff.png", dpi=150); plt.close()

    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    _bar(ax[0], e2, ["Leakage", "Coverage"], "Ablations: leakage and coverage")
    _bar(ax[1], e2, ["Score", "ForgetSuccess"], "Ablations: Score and forget success")
    plt.tight_layout(); plt.savefig(f"{out}/fig3_ablation.png", dpi=150); plt.close()

    fig, ax = plt.subplots(figsize=(6, 4))
    t = e4.copy(); t["p"] = [float(i.split("p=")[1]) for i in t.index]; t["cfg"] = [i.split(" p=")[0] for i in t.index]
    for k, (c, g) in enumerate(t.groupby("cfg")):
        g = g.sort_values("p"); ax.plot(g.p, g.Leakage, marker="o", color=PAL[k], label=c)
    ax.set_xlabel("Fraction of provenance edges missed"); ax.set_ylabel("Leakage (%)")
    ax.set_title("Robustness to incomplete provenance", fontsize=10); ax.legend(fontsize=8, frameon=False)
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout(); plt.savefig(f"{out}/fig4_noise.png", dpi=150); plt.close()

    fig, ax = plt.subplots(figsize=(8, 4))
    t = e7[(e7.edge_drop == 0.0)]
    for k, (coh, g) in enumerate(t.groupby("coherence")):
        ax.bar([i + k * 0.4 for i in range(len(g))], g.accuracy, 0.4, color=PAL[k], label=f"session coherence {coh}",
               yerr=[g.accuracy - g.ci_lo, g.ci_hi - g.accuracy], capsize=2)
    ax.axhline(100 / 12, color="gray", ls="--", lw=1); ax.text(0, 100 / 12 + 2, "chance (1/12)", fontsize=8, color="gray")
    ax.set_xticks([i + 0.2 for i in range(len(g))]); ax.set_xticklabels(g.config, rotation=25, ha="right", fontsize=8)
    ax.set_ylabel("Attacker accuracy on deleted category (%)"); ax.set_title("Tombstone study", fontsize=10)
    ax.legend(fontsize=8, frameon=False); ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout(); plt.savefig(f"{out}/fig5_tombstones.png", dpi=150); plt.close()

    e8 = e9 = None
    if os.path.exists(f"{out}/E8_judge_noise.csv"):
        e8 = r("E8_judge_noise")
        fig, ax = plt.subplots(figsize=(6.5, 4))
        t = e8.copy(); t["q"] = [float(i.split("miss=")[1]) for i in t.index]; t["cfg"] = [i.split(" miss=")[0] for i in t.index]
        for k, (c, g) in enumerate(t.groupby("cfg")):
            g = g.sort_values("q"); ax.plot(g.q, g.Leakage, marker="o", color=PAL[k], label=c)
        ax.set_xlabel("Judge miss rate (finder judge fails to flag a true match)"); ax.set_ylabel("Leakage (%)")
        ax.set_title("Guard and repair loop under an unreliable judge", fontsize=10); ax.legend(fontsize=7, frameon=False)
        ax.spines[["top", "right"]].set_visible(False)
        plt.tight_layout(); plt.savefig(f"{out}/fig6_judge_noise.png", dpi=150); plt.close()
    if os.path.exists(f"{out}/E9_verifier_detection.csv"):
        e9 = r("E9_verifier_detection")
    show = ["RA", "FE", "PR", "RLA", "AR", "RPR", "Score", "Leakage", "ForgetSuccess", "OverForget", "Coverage", "SecPerForget", "TokPerForget"]
    e1 = e1.assign(MsPerForget=e1.SecPerForget * 1000)
    show = [c if c != "SecPerForget" else "MsPerForget" for c in show]
    e1s = e1[show].copy(); e1s["Score_ci"] = [f"[{a:.1f}, {b:.1f}]" for a, b in zip(e1.Score_lo, e1.Score_hi)]
    e2s = e2[["Score", "FE", "AR", "Leakage", "ForgetSuccess", "Coverage"]]
    e7s = e7[(e7.edge_drop == 0.0)].pivot(index="config", columns="coherence", values="accuracy")
    e7s.columns = [f"acc @ coherence {c}" for c in e7s.columns]
    text = f"""# Results (auto-generated by `python -m bench.run`)

> **Read this first.** These numbers come from the deterministic **offline backend** on a **synthetic benchmark generated
> from the same lexicon** ({meta['n_instances']} instances x seeds {meta['seeds']}; {meta['n_requests']} forget requests,
> {meta['n_questions']} questions, {meta['multi_agent']} multi-agent instances). They measure the *architecture*
> (provenance, cascade, guard, repair) under controlled conditions. They are **not** BEMULA results, **not** measurements of any
> LLM, and must not be quoted as such. `InstructionSuppress(sim)`, `Mem0Style` and `SBUStyle` are re-implementations of a policy/idea
> (see bench/systems.py), not the original libraries or papers' code. Real-LLM / real-BEMULA runs are still to do (docs/RUNBOOK.md).

Metric definitions follow BEMULA (Xie et al., 2026), Eq. 2-5: paired control probes, effective correctness, Score = sqrt(FE*AR) * sqrt(PR*RLA).
Extras: **Leakage** = % of efficacy+attack probes (control-valid) revealing the target under an evaluator-side oracle (alias in text OR answer built from a
memory whose hidden lineage includes the target); **ForgetSuccess** = % requests with zero leaks; **OverForget**; **Coverage** = % of
memory derived from non-target facts that survives (evaluator-side lineage metric; PR alone cannot see summary-tier damage because raw memories survive).
`ceiling`: attack/efficacy items count only if the control version also answered them, so Score cannot reach 100 on this generator.

## E1. Main comparison
{md(e1s)}

![main](fig1_main.png) ![tradeoff](fig2_tradeoff.png)

## E2. Ablations
{md(e2s)}

![ablation](fig3_ablation.png)

## E4. Incomplete provenance (fraction of graph edges missed)
{md(e4)}

![noise](fig4_noise.png)

*Reading:* with a complete graph, ablating the repair loop costs nothing; its value appears only when provenance is incomplete AND the missed copy is
visible to a probe (cue-bearing text). Copies whose text carries no cue (depth-3 neutral notes) are invisible to text-based probes: the verifier cannot repair what it cannot see. That is a limitation, shown honestly here.

## E5. Second answerer profile (stand-in for a second backbone; NOT a different LLM)
{md(e5[['Score','FE','AR','Leakage','Coverage']])}

## E6. Parser accuracy (offline parser, exact target match)
{md(e6.rename(columns={e6.columns[0]: 'accuracy %'}))}

Code-mixed vs English: {md(e6c.rename(columns={e6c.columns[0]: 'accuracy %'}))}  (code-mixed templates are my own and not human-validated)

## E7. Tombstone / deletion-pattern study
{md(e7s)}

![tombstones](fig5_tombstones.png)

Attacker = rule-based (marker reader, id-gap/neighbour voting, residual-cue voting); chance = 8.3%. A descriptive marker leaks the deleted category
with certainty. Other styles are statistically near chance against *this* attacker; that is not a proof of safety against stronger (learned/LLM) attackers.
The gap/neighbour signal depends on session coherence, an assumption about real conversations.

{('## E8. Unreliable judge: value of the guard and the repair loop' + chr(10) + md(e8) + chr(10) + chr(10) + '![judge noise](fig6_judge_noise.png)') if e8 is not None else ''}

{('## E9. What the verifier detects after each system forgets (30 instances, per request)' + chr(10) + md(e9) + chr(10) + chr(10) + 'probe_leak_rate = some Q&A / tool probe revealed the target; physical_residue_rate = target string still present in raw database bytes; verifier_leak_rate = any check failed.') if e9 is not None else ''}

## E3. Leakage by slice (control-valid probes)
{md(e3.set_index('system').round(1).reset_index().set_index('system'))}
"""
    open(f"{out}/RESULTS.md", "w").write(text)
