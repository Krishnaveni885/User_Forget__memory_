"""Systems under test. All share the same ingestion, retrieval and answerer; they differ ONLY in the forget path.

  NoDeletion     floor: the request changes nothing
  LogicalOnly    marks matched rows 'deleted' (vectors + rows remain; SQL tools still see them)
  DeleteByID     physically deletes the matched rows + vectors (what most libraries do); no derived copies
  PromptSuppress SIMULATED full-context "please ignore this": suppresses questions that mention the target surface form
  Mem0Style      re-implementation of the *policy* "compare request to the most similar memory, delete that one"
  SBUStyle       re-implementation of the *idea* of dependency closure, same-agent, purge-only, one shot
  ForgetMe*      the full method and its ablations
Baselines marked SIMULATED / re-implementation are NOT the original libraries (see docs/LIMITATIONS.md).
"""
from __future__ import annotations

from forgetme.agent import MemoryHub
from forgetme.config import ForgetConfig
from forgetme.finder import find_targets
from forgetme.llm import OfflineBackend
from forgetme.models import TargetSpec
from forgetme.pipeline import ForgetMe
from forgetme.planner import Action, Plan, plan_cascade
from forgetme.provenance import ProvenanceGraph


class MemorySystem:
    name = "base"
    cfg_kwargs: dict = {}

    def __init__(self, depth: int = 3, seed: int = 0, profile: str = "lenient", edge_drop: float = 0.0):
        self.cfg = ForgetConfig(seed=seed, **self.cfg_kwargs)
        self.hub = MemoryHub(backend=OfflineBackend(profile), cfg=self.cfg)
        self.depth = depth
        self.A, self.B = self.hub.agent("A"), self.hub.agent("B")
        self.edge_drop = edge_drop
        self.forget_seconds = 0.0
        self.forget_tokens = 0
        self.n_forgets = 0

    # --- environment events (identical for every system)
    def ingest(self, ev, version: str):
        ag = self.hub.agent(ev.agent)
        if ev.kind == "user":
            ag.observe(ev.text, fact_id=ev.fact_id)
        elif ev.kind == "filler":
            ag.observe(ev.text)
        elif ev.kind == "end_session":
            ag.end_session(self.depth)
        elif ev.kind == "share":
            fs = set(ev.fact_ids)
            ids = [m.id for m in self.hub.store.all(("live",), "A")
                   if m.meta.get("roots") and set(m.meta["roots"]) <= fs]
            self.hub.share("A", "B", ids)
        elif ev.kind == "forget":
            if version == "forget":
                import time
                t0, k0 = time.perf_counter(), self.hub.backend.tokens
                ag.observe(ev.text)                       # the request is an ordinary user turn
                self.on_forget(ev.text)
                self.forget_seconds += time.perf_counter() - t0
                self.forget_tokens += self.hub.backend.tokens - k0
                self.n_forgets += 1
            else:
                ag.observe(ev.control_text)
        elif ev.kind == "relearn":
            ag.observe(ev.text)
            ag.end_session(self.depth)

    def on_forget(self, text: str): ...

    def answer(self, question: str, agent: str = "A"):
        return self.hub.agent(agent).answer(question, fresh=True)

    # helpers for baselines
    def _target(self, text):
        p = self.hub.backend.parse_request(text)
        return None if p.needs_clarification else TargetSpec.from_parsed(p), p


class NoDeletion(MemorySystem):
    name = "NoDeletion"


class LogicalOnly(MemorySystem):
    name = "LogicalOnly"

    def on_forget(self, text):
        t, _ = self._target(text)
        if t:
            for i in find_targets(self.hub, t, self.cfg, ["A"]).matched:
                self.hub.store.set_status(i, "deleted")


class DeleteByID(MemorySystem):
    name = "DeleteByID"

    def on_forget(self, text):
        t, _ = self._target(text)
        if not t:
            return
        ids = sorted(find_targets(self.hub, t, self.cfg, ["A"]).matched)
        for i in ids:
            self.hub.index.delete(i)
            self.hub.owner.pop(i, None)
        self.hub.store.delete(ids, vacuum=False)
        self.A.cache.clear()


class PromptSuppress(MemorySystem):
    """SIMULATED instruction-following: nothing is deleted. The answerer refuses when the *question* literally
    contains a surface form of a suppressed target, unless an override prefix is present."""
    name = "PromptSuppress(sim)"

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.suppressed: list[TargetSpec] = []

    def on_forget(self, text):
        t, _ = self._target(text)
        if t:
            self.suppressed.append(t)

    def answer(self, question, agent="A"):
        q = question.lower()
        from forgetme.agent import Answer
        override = "disregard any earlier" in q or "ignore" in q
        for t in self.suppressed:
            if not override and any(a in q for a in t.alias_terms()):
                return Answer("I don't have that information.", [])
        return super().answer(question, agent)


class Mem0Style(MemorySystem):
    name = "Mem0Style(sim)"

    def on_forget(self, text):
        t, _ = self._target(text)
        if not t:
            return
        qv = self.hub.embedder.embed([text])[0]
        for i, s in self.hub.index.search(qv, k=1):
            m = self.hub.store.get(i)
            if m and m.agent_id == "A" and self.hub.backend.judge_contains(m.text, t):
                self.hub.index.delete(i)
                self.hub.store.delete([i], vacuum=False)
                self.hub.owner.pop(i, None)


class SBUStyle(MemorySystem):
    name = "SBUStyle(sim)"

    def on_forget(self, text):
        t, _ = self._target(text)
        if not t:
            return
        matched = find_targets(self.hub, t, self.cfg, ["A"]).matched
        g = ProvenanceGraph.from_store(self.hub.store, cross_agent=False)
        ids = sorted(i for i in g.closure(matched) if self.hub.store.get(i).status == "live")
        for i in ids:
            self.hub.index.delete(i)
            self.hub.owner.pop(i, None)
        self.hub.store.delete(ids, vacuum=False)
        self.A.cache.clear()


class ForgetMeSystem(MemorySystem):
    name = "ForgetMe"

    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.fm = ForgetMe(self.hub, self.cfg, graph_edge_drop=self.edge_drop)

    def on_forget(self, text):
        self.fm.forget(text, "A")


def _fm(name, **cfgkw):
    return type(name, (ForgetMeSystem,), {"name": name, "cfg_kwargs": cfgkw})


ForgetMeFull = _fm("ForgetMe-full")
NoGuard = _fm("ForgetMe-noGuard", use_guard=False)
NoRepair = _fm("ForgetMe-noRepair", use_repair=False)
NoVerifier = _fm("ForgetMe-noVerifier", use_verifier=False, use_repair=False, use_guard=False)
NoGraph = _fm("ForgetMe-noGraph", use_graph=False)
NoCrossAgent = _fm("ForgetMe-noCrossAgent", cross_agent=False)

BASELINES = [NoDeletion, LogicalOnly, DeleteByID, PromptSuppress, Mem0Style, SBUStyle]
ABLATIONS = [ForgetMeFull, NoGuard, NoRepair, NoGraph, NoCrossAgent, NoVerifier]
ALL = {c.name: c for c in BASELINES + ABLATIONS}
