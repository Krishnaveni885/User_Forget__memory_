"""Forget-Me pipeline: parse -> find -> closure -> plan -> execute -> verify -> (repair) -> receipt."""
from __future__ import annotations

import time
import uuid

from pydantic import BaseModel, Field

from .config import ForgetConfig
from .executor import execute
from .finder import find_targets
from .models import ParsedRequest, TargetSpec
from .planner import plan_cascade
from .provenance import ProvenanceGraph
from .receipts import ReceiptLog, state_digest
from .tombstones import AuditVault
from .verifier import Verifier, VerificationReport


class ForgetReport(BaseModel):
    """The deletion report from the guide (section 5), plus the extra fields the method adds."""
    request_id: str
    status: str = "done"              # done | needs_clarification | nothing_found
    clarifying_question: str | None = None
    kind: str | None = None
    deleted: list[int] = Field(default_factory=list)
    rewritten: list[dict] = Field(default_factory=list)
    tombstoned: list[int] = Field(default_factory=list)
    kept: list[int] = Field(default_factory=list)
    index_entries_removed: int = 0
    leak_test: dict = Field(default_factory=dict)
    repair_rounds: int = 0
    receipt_hash: str | None = None
    cost: dict = Field(default_factory=dict)
    verification: VerificationReport | None = None


class ForgetMe:
    def __init__(self, hub, cfg: ForgetConfig | None = None, receipts: ReceiptLog | None = None,
                 vault: AuditVault | None = None, graph_edge_drop: float = 0.0):
        self.hub = hub
        self.cfg = cfg or hub.cfg
        hub.cfg = self.cfg
        self.receipts = receipts or ReceiptLog()
        self.vault = vault or AuditVault()
        self.graph_edge_drop = graph_edge_drop     # robustness experiments: simulate incomplete provenance
        self._rng = __import__("random").Random(self.cfg.seed)

    def _graph(self):
        if not self.cfg.use_graph:
            return None
        g = ProvenanceGraph.from_store(self.hub.store, cross_agent=self.cfg.cross_agent)
        if self.graph_edge_drop > 0:
            g = g.with_dropped_edges(self.graph_edge_drop, self._rng)
        return g

    def forget(self, request: str, agent_id: str = "A", control_agent=None,
               parsed: ParsedRequest | None = None) -> ForgetReport:
        hub, cfg, backend = self.hub, self.cfg, self.hub.backend
        t0, calls0, tok0 = time.perf_counter(), backend.calls, backend.tokens
        rid = str(uuid.uuid4())
        # 1) parse (validated); vague requests -> clarifying question, nothing is touched
        parsed = parsed or backend.parse_request(request)
        if parsed.needs_clarification:
            return ForgetReport(request_id=rid, status="needs_clarification", kind=parsed.kind,
                                clarifying_question=parsed.clarifying_question)
        target = TargetSpec.from_parsed(parsed)
        before = state_digest(hub.store, hub.key)
        agent_ids = None if cfg.cross_agent else [agent_id]

        # 2-3) find + closure + plan
        found = find_targets(hub, target, cfg, agent_ids)
        if not found.matched:
            return ForgetReport(request_id=rid, status="nothing_found", kind=parsed.kind)
        plan = plan_cascade(self._graph(), hub.store, found.matched, target, cfg, backend)
        # 4) execute
        res = execute(hub, plan, target, cfg, self.vault, rid)
        deleted, rewritten, tombs = set(res.purged), {r["id"]: r for r in res.rewritten}, set(res.tombstoned)
        removed_index = res.index_entries_removed

        # 5) verify + repair loop
        report: VerificationReport | None = None
        rounds = 0
        if cfg.use_verifier:
            ver = Verifier(hub, cfg, control_agent)
            for rounds in range(1, cfg.max_repair_rounds + 1):
                report = ver.verify(target, primary=agent_id)
                if report.passed or not cfg.use_repair:
                    break
                new = {i for i in report.leak_sources if hub.store.get(i) and hub.store.get(i).status in ("live", "archived")}
                if not new:
                    break
                plan2 = plan_cascade(self._graph(), hub.store, new, target, cfg, backend)
                res2 = execute(hub, plan2, target, cfg, self.vault, rid)
                deleted |= set(res2.purged); tombs |= set(res2.tombstoned)
                for r in res2.rewritten:
                    rewritten[r["id"]] = r
                removed_index += res2.index_entries_removed
                res.kept = sorted(set(res.kept) | set(res2.kept))
            if report is not None and not report.passed and cfg.use_repair and rounds == cfg.max_repair_rounds:
                report = ver.verify(target, primary=agent_id)      # final measurement after the last repair
            rounds = max(rounds, 1)

        lt = {}
        if report is not None:
            g = ver.verify(target, primary=agent_id, audit=False)
            guarded = sum(v["leaks"] for v in g.by_style.values())     # what a user could actually extract
            lt = {"guarded_leaks_found": guarded, "probes_run": report.probes_run, "leaks_found": report.leaks_found,
                  "control_false_positive_rate": report.control_false_positive_rate,
                  "by_style": report.by_style, "passed": report.passed}
        after = state_digest(hub.store, hub.key)
        counts = {"purged": len(deleted), "rewritten": len(rewritten), "tombstoned": len(tombs),
                  "kept": len(res.kept), "index_entries_removed": removed_index}
        rec = self.receipts.write_receipt(
            request_text=request, target_desc=f"{target.kind}|{sorted(target.concept_ids)}|{sorted(target.inference_ids)}|"
                                              f"{sorted(target.categories)}|{target.period}",
            plan_counts=counts, executed_ids=sorted(deleted | tombs | set(rewritten)),
            verification={k: lt.get(k) for k in ("probes_run", "leaks_found", "guarded_leaks_found", "control_false_positive_rate", "passed")},
            rounds=rounds, tombstone_style=cfg.tombstone_style, state_before=before, state_after=after,
            config=cfg.to_dict(), request_id=rid)
        return ForgetReport(
            request_id=rid, kind=parsed.kind, deleted=sorted(deleted), rewritten=sorted(rewritten.values(), key=lambda r: r["id"]),
            tombstoned=sorted(tombs), kept=sorted(set(res.kept) - deleted - tombs), index_entries_removed=removed_index,
            leak_test=lt, repair_rounds=rounds, receipt_hash="sha256:" + rec["receipt_hash"], verification=report,
            cost={"seconds": round(time.perf_counter() - t0, 4), "llm_calls": backend.calls - calls0,
                  "tokens": backend.tokens - tok0})
