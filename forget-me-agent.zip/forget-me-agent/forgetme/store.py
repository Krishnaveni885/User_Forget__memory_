"""SQLite memory store: records + provenance edges. Deletion can be physical.

Schema = the guide's record: id, text, tier, parents, agent_id, created_at, embedding_id.
`meta` holds gist, concept tags, evaluator-only `roots` lineage (never read by core logic).
"""
from __future__ import annotations

import json
import os
import sqlite3
from typing import Iterable

from pydantic import BaseModel, Field

TIERS = ("raw", "summary", "derived")


class Memory(BaseModel):
    id: int
    text: str
    tier: str
    parents: list[int] = Field(default_factory=list)
    agent_id: str = "A"
    created_at: float = 0.0
    embedding_id: int | None = None
    status: str = "live"            # live | tombstone | deleted(logical)
    meta: dict = Field(default_factory=dict)

    @property
    def gist(self) -> str:
        return self.meta.get("gist") or self.text


SCHEMA = """
CREATE TABLE IF NOT EXISTS memories(
  id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, tier TEXT NOT NULL,
  agent_id TEXT NOT NULL, created_at REAL NOT NULL, embedding_id INTEGER,
  status TEXT NOT NULL DEFAULT 'live', meta TEXT NOT NULL DEFAULT '{}');
CREATE TABLE IF NOT EXISTS edges(
  parent INTEGER NOT NULL, child INTEGER NOT NULL, cross_agent INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(parent, child));
"""


class MemoryStore:
    def __init__(self, path: str = ":memory:"):
        self.path = path
        self.conn = sqlite3.connect(path)
        self.conn.execute("PRAGMA secure_delete=ON")     # overwrite freed pages with zeros
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    # ---------- writes
    def add(self, text: str, tier: str, agent_id: str, parents: Iterable[int] = (), meta: dict | None = None,
            created_at: float = 0.0, cross_agent: bool = False) -> int:
        cur = self.conn.execute(
            "INSERT INTO memories(text,tier,agent_id,created_at,meta) VALUES(?,?,?,?,?)",
            (text, tier, agent_id, created_at, json.dumps(meta or {})))
        mid = cur.lastrowid
        self.conn.execute("UPDATE memories SET embedding_id=? WHERE id=?", (mid, mid))
        for p in parents:
            self.conn.execute("INSERT OR IGNORE INTO edges VALUES(?,?,?)", (p, mid, int(cross_agent)))
        self.conn.commit()
        return mid

    def update_text(self, mid: int, text: str, meta_updates: dict | None = None):
        m = self.get(mid)
        meta = dict(m.meta)
        meta.update(meta_updates or {})
        self.conn.execute("UPDATE memories SET text=?, meta=? WHERE id=?", (text, json.dumps(meta), mid))
        self.conn.commit()

    def set_status(self, mid: int, status: str):
        self.conn.execute("UPDATE memories SET status=? WHERE id=?", (status, mid))
        self.conn.commit()

    def tombstone(self, mid: int, marker: str):
        self.conn.execute(
            "UPDATE memories SET text=?, status='tombstone', embedding_id=NULL, meta='{}' WHERE id=?", (marker, mid))
        self.conn.commit()

    def remove_edges(self, parent: int | None = None, child: int | None = None):
        if parent is not None and child is not None:
            self.conn.execute("DELETE FROM edges WHERE parent=? AND child=?", (parent, child))
        elif parent is not None:
            self.conn.execute("DELETE FROM edges WHERE parent=?", (parent,))
        elif child is not None:
            self.conn.execute("DELETE FROM edges WHERE child=?", (child,))
        self.conn.commit()

    def delete(self, ids: Iterable[int], vacuum: bool = True):
        ids = list(ids)
        for i in ids:
            self.conn.execute("DELETE FROM memories WHERE id=?", (i,))
            self.conn.execute("DELETE FROM edges WHERE parent=? OR child=?", (i, i))
        self.conn.commit()
        if vacuum:
            self.conn.execute("VACUUM")
            if self.path != ":memory:":
                self.conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")

    def renumber(self) -> dict[int, int]:
        """Compact ids to 1..n in creation order (hides id gaps left by deletion)."""
        rows = self.conn.execute("SELECT id FROM memories ORDER BY created_at, id").fetchall()
        mapping = {old: new for new, (old,) in enumerate(rows, start=1)}
        c = self.conn
        c.execute("PRAGMA foreign_keys=OFF")
        c.execute("CREATE TEMP TABLE idmap(old INTEGER PRIMARY KEY, new INTEGER)")
        c.executemany("INSERT INTO idmap VALUES(?,?)", list(mapping.items()))
        c.execute("CREATE TABLE memories2 AS SELECT m.*, i.new AS nid FROM memories m JOIN idmap i ON i.old=m.id")
        c.execute("CREATE TABLE edges2 AS SELECT a.new AS p, b.new AS c, e.cross_agent AS x FROM edges e "
                  "JOIN idmap a ON a.old=e.parent JOIN idmap b ON b.old=e.child")
        c.execute("DROP TABLE memories"); c.execute("DROP TABLE edges"); c.execute("DROP TABLE idmap")
        c.executescript(SCHEMA)
        c.execute("INSERT INTO memories(id,text,tier,agent_id,created_at,embedding_id,status,meta) "
                  "SELECT nid,text,tier,agent_id,created_at,CASE WHEN embedding_id IS NULL THEN NULL ELSE nid END,"
                  "status,meta FROM memories2")
        c.execute("INSERT INTO edges SELECT p,c,x FROM edges2")
        c.execute("DROP TABLE memories2"); c.execute("DROP TABLE edges2")
        c.commit()
        c.execute("VACUUM")
        return mapping

    # ---------- reads
    @staticmethod
    def _row(r, parents) -> Memory:
        return Memory(id=r[0], text=r[1], tier=r[2], agent_id=r[3], created_at=r[4], embedding_id=r[5],
                      status=r[6], meta=json.loads(r[7]), parents=parents)

    def get(self, mid: int) -> Memory | None:
        r = self.conn.execute("SELECT id,text,tier,agent_id,created_at,embedding_id,status,meta FROM memories WHERE id=?",
                              (mid,)).fetchone()
        return self._row(r, self.parents(mid)) if r else None

    def all(self, statuses: tuple[str, ...] = ("live",), agent_id: str | None = None) -> list[Memory]:
        q = "SELECT id,text,tier,agent_id,created_at,embedding_id,status,meta FROM memories"
        cond, args = [], []
        if statuses:
            cond.append("status IN (%s)" % ",".join("?" * len(statuses))); args += list(statuses)
        if agent_id:
            cond.append("agent_id=?"); args.append(agent_id)
        if cond:
            q += " WHERE " + " AND ".join(cond)
        q += " ORDER BY id"
        pmap: dict[int, list[int]] = {}
        for p, c in self.conn.execute("SELECT parent, child FROM edges"):
            pmap.setdefault(c, []).append(p)
        return [self._row(r, sorted(pmap.get(r[0], []))) for r in self.conn.execute(q, args)]

    def ids(self, statuses=("live",)) -> set[int]:
        return {m.id for m in self.all(statuses)}

    def parents(self, mid: int) -> list[int]:
        return [r[0] for r in self.conn.execute("SELECT parent FROM edges WHERE child=? ORDER BY parent", (mid,))]

    def children(self, mid: int) -> list[int]:
        return [r[0] for r in self.conn.execute("SELECT child FROM edges WHERE parent=? ORDER BY child", (mid,))]

    def edges(self) -> list[tuple[int, int, int]]:
        return list(self.conn.execute("SELECT parent, child, cross_agent FROM edges"))

    def search_text(self, needle: str, agent_id: str | None = None) -> list[Memory]:
        """Naive SQL LIKE 'search tool' (ignores status!) - an attack/tool route."""
        q = "SELECT id,text,tier,agent_id,created_at,embedding_id,status,meta FROM memories WHERE lower(text) LIKE ?"
        args = ["%" + needle.lower() + "%"]
        if agent_id:
            q += " AND agent_id=?"; args.append(agent_id)
        return [self._row(r, self.parents(r[0])) for r in self.conn.execute(q, args)]

    def raw_bytes(self) -> bytes:
        """Raw database bytes, for a physical-deletion scan."""
        self.conn.commit()
        if self.path == ":memory:":
            return bytes(self.conn.serialize())
        with open(self.path, "rb") as f:
            data = f.read()
        wal = self.path + "-wal"
        if os.path.exists(wal):
            with open(wal, "rb") as f:
                data += f.read()
        return data

    def count(self) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
