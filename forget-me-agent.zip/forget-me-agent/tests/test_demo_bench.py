import pandas as pd
from fastapi.testclient import TestClient
from app.api import app
from forgetme.demo import DemoSession
from bench.synth import generate_dataset
from bench.systems import ALL
from bench.metrics import run_instance, aggregate


def test_demo_session_control_fpr_and_receipt():
    s = DemoSession()
    rep = s.forget("Forget that I have diabetes")
    assert rep.status == "done" and rep.leak_test["leaks_found"] == 0
    assert rep.leak_test["control_false_positive_rate"] is not None and rep.leak_test["control_false_positive_rate"] <= 0.2
    assert s.verify_receipts()[0]
    assert "diabet" not in s.ask("What chronic medical condition was I diagnosed with?", "B")["answer"].lower()


def test_api_roundtrip():
    c = TestClient(app)
    sid = c.post("/sessions", json={}).json()["session"]
    assert len(c.get(f"/sessions/{sid}/memories").json()) > 10
    r = c.post(f"/sessions/{sid}/forget", json={"request": "Forget that I have diabetes"}).json()
    assert r["status"] == "done" and r["leak_test"]["leaks_found"] == 0
    r = c.post(f"/sessions/{sid}/forget", json={"request": "forget what I told you yesterday"}).json()
    assert r["status"] == "needs_clarification"
    rc = c.get(f"/sessions/{sid}/receipts").json()
    assert rc["chain_ok"] and len(rc["receipts"]) == 1


def test_benchmark_is_deterministic_and_paired():
    a, b = generate_dataset(5, 3), generate_dataset(5, 3)
    assert [i.stats() for i in a] == [i.stats() for i in b]
    for inst in a:
        kinds = {r.kind for r in inst.requests}
        assert {q.suite for q in inst.questions} >= {"efficacy", "attack", "preservation"}
        assert sum(q.suite == "preservation" for q in inst.questions) == 3
        for r in inst.requests:   # request targets never overlap preserved F4 sources
            assert not set(r.target_facts) & set(r.source_facts)


def test_metric_sanity_floor_and_ceiling():
    ds = generate_dataset(8, 11)
    def score(name):
        rows = []
        for inst in ds:
            r, _ = run_instance(ALL[name], inst); rows += r
        return aggregate(rows)
    floor, full = score("NoDeletion"), score("ForgetMe-full")
    assert floor["Leakage"] > 90 and floor["Score"] == 0                 # forgetting nothing earns nothing
    assert full["Leakage"] < 5 and full["Score"] > floor["Score"] + 50
    assert full["RA"] == 100 and full["RLA"] >= 95                       # system can still store / relearn
