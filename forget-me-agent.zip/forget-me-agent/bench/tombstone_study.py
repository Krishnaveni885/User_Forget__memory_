"""Step 10: do the leftovers of a deletion (markers, id gaps, neighbours) leak what was deleted?

Attacker sees only the post-deletion live store (texts, tiers, ids, edges) and knows the lexicon.
  marker    : reads the category from a descriptive marker
  neighbour : finds the deletion position (tombstone row, or a gap in raw-memory ids) and guesses the category of
              the adjacent raw memories (sessions are topically coherent with probability `coherence`)
  combined  : marker first, otherwise neighbour, otherwise uniform guess
Chance = 1/12 (uniform over the 12 categories).  `coherence` is an ASSUMPTION about real conversations, so results
are reported for several values rather than one.
"""
from __future__ import annotations

import random
from collections import Counter

import pandas as pd

from forgetme.agent import MemoryHub
from forgetme.config import ForgetConfig
from forgetme.lexicon import CATEGORIES, CONCEPTS, CATEGORY_LABEL
from forgetme.pipeline import ForgetMe

STYLES = [("none", False), ("descriptive", False), ("generic", False), ("encrypted_log", False), ("encrypted_log", True)]
LABEL2CAT = {c.label: c.category for c in CONCEPTS.values()} | {v: k for k, v in CATEGORY_LABEL.items()}


def _persona(rng: random.Random, coherence: float, n=10):
    cids = rng.sample(sorted(CONCEPTS), n)
    order = []
    pool = cids[:]
    rng.shuffle(pool)
    while pool:
        c = pool.pop()
        order.append(c)
        if rng.random() < coherence:                    # next fact comes from the same category if possible
            same = [x for x in pool if CONCEPTS[x].category == CONCEPTS[c].category]
            if same:
                nxt = rng.choice(same); pool.remove(nxt); order.append(nxt)
    return order


def _attack(hub, style, compact, target_cat_unused, rng):
    st = hub.store
    live = st.all(("live", "tombstone"))
    # marker attacker
    marker_guess = None
    for m in live:
        if m.status == "tombstone":
            for lab, cat in LABEL2CAT.items():
                if lab in m.text:
                    marker_guess = cat
    # neighbour attacker: position of the deletion among raw memories
    raws = [m for m in live if m.tier == "raw" or m.status == "tombstone"]
    ids = sorted(m.id for m in raws)
    pos = None
    tomb = [m.id for m in raws if m.status == "tombstone"]
    if tomb:
        pos = tomb[0]
    else:
        raw_only = sorted(m.id for m in live if m.tier == "raw")
        for a, b in zip(raw_only, raw_only[1:]):
            if b - a > 1:
                pos = a + 0.5; break
        if pos is None and raw_only and raw_only[0] > 1:
            pos = 0.5
    neigh_guess = None
    if pos is not None:
        rawlive = sorted([m for m in live if m.tier == "raw" and m.status == "live"], key=lambda m: m.id)
        before = [m for m in rawlive if m.id < pos][-1:]
        after = [m for m in rawlive if m.id > pos][:1]
        cats = [CONCEPTS[m.meta["concept"]].category for m in before + after if m.meta.get("concept")]
        if cats:
            neigh_guess = Counter(cats).most_common(1)[0][0]
    uniform = rng.choice(CATEGORIES)
    return marker_guess, neigh_guess, marker_guess or neigh_guess or uniform


def run_study(trials=400, seed=0, coherences=(0.0, 0.7)) -> pd.DataFrame:
    rng = random.Random(seed)
    rows = []
    for coh in coherences:
        for style, compact in STYLES:
            hit = Counter(); n = 0
            for t in range(trials):
                order = _persona(rng, coh)
                cfg = ForgetConfig(tombstone_style=style, tombstone_scope="all", compact_ids=compact, use_verifier=False,
                                   seed=t)
                hub = MemoryHub(cfg=cfg)
                a = hub.agent("A")
                for c in order:
                    a.observe(CONCEPTS[c].utter[0], fact_id=f"f_{c}")
                a.end_session(derive_depth=1)
                victim = rng.choice(order)
                ForgetMe(hub, cfg).forget(f"Forget that I {CONCEPTS[victim].fact}.")
                truth = CONCEPTS[victim].category
                m, nb, comb = _attack(hub, style, compact, truth, rng)
                n += 1
                hit["marker"] += (m == truth); hit["neighbour"] += (nb == truth); hit["combined"] += (comb == truth)
            name = style + ("+compact_ids" if compact else "")
            rows.append({"coherence": coh, "style": name, "marker": hit["marker"] / n, "neighbour": hit["neighbour"] / n,
                         "combined": hit["combined"] / n, "chance": 1 / len(CATEGORIES), "trials": n})
    return pd.DataFrame(rows)


def study_markdown(df: pd.DataFrame) -> str:
    from .run import md_table
    d = df.copy()
    for c in ["marker", "neighbour", "combined", "chance"]:
        d[c] = d[c].map(lambda x: f"{100 * x:.1f}%")
    return ("Attacker accuracy at guessing the deleted fact's **category** from what is left behind "
            "(chance = 8.3%). `coherence` = probability that adjacent facts share a category (an assumption).\n\n"
            + md_table(d))


if __name__ == "__main__":
    print(study_markdown(run_study(200)))
