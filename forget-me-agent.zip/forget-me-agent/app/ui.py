"""Streamlit demo.   streamlit run app/ui.py"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import json
import streamlit as st
from forgetme.config import ForgetConfig
from forgetme.demo import DemoSession

st.set_page_config(page_title="Forget-Me Agent", layout="wide")
st.title("Forget-Me Agent: verifiable erasure for agent memory")
st.caption("Offline deterministic backend with synthetic data only. Do not enter real personal or medical data.")

with st.sidebar:
    st.header("Configuration")
    style = st.selectbox("Tombstone style", ["none", "descriptive", "generic", "encrypted_log"])
    guard = st.checkbox("Read-time guard", True)
    repair = st.checkbox("Verify + repair loop", True)
    graph = st.checkbox("Provenance closure", True)
    cross = st.checkbox("Cross-agent erasure", True)
    if st.button("Reset session") or "sess" not in st.session_state:
        st.session_state.sess = DemoSession(ForgetConfig(tombstone_style=style, use_guard=guard, use_repair=repair,
                                                         use_graph=graph, cross_agent=cross))
        st.session_state.last = None
s = st.session_state.sess

c1, c2 = st.columns([3, 2])
with c1:
    st.subheader("Memory store (all agents)")
    st.dataframe(s.memories(), width="stretch", height=380)
    g = s.graph().g
    dot = "digraph {rankdir=LR; node [shape=box,fontsize=9];\n"
    for m in s.memories():
        col = {"raw": "lightblue", "summary": "khaki", "derived": "lightgreen"}.get(m["tier"], "white")
        if m["status"] == "tombstone": col = "salmon"
        dot += f'{m["id"]} [label="{m["id"]} {m["agent"]}/{m["tier"]}\\n{m["text"][:28].replace(chr(34), "")}", style=filled, fillcolor={col}];\n'
    for u, v in g.edges:
        dot += f"{u} -> {v}" + (" [style=dashed,color=red]" if g.edges[u, v].get("cross_agent") else "") + ";\n"
    st.graphviz_chart(dot + "}")
with c2:
    st.subheader("Ask an agent")
    ag = st.radio("Agent", ["A", "B"], horizontal=True)
    q = st.text_input("Question", "What chronic medical condition was I diagnosed with?")
    if st.button("Ask"):
        st.json(s.ask(q, ag))
    st.subheader("Forget request")
    req = st.text_input("Request", "Forget that I have diabetes")
    if st.button("Forget it", type="primary"):
        st.session_state.last = s.forget(req)
    rep = st.session_state.last
    if rep:
        if rep.status == "needs_clarification":
            st.warning(rep.clarifying_question)
        else:
            st.success(f"{len(rep.deleted)} deleted, {len(rep.rewritten)} rewritten, {len(rep.tombstoned)} tombstoned, "
                       f"{rep.index_entries_removed} index entries removed, {rep.repair_rounds} verify round(s)")
            st.json(rep.model_dump(exclude={"verification", "request_id"}))
    st.subheader("Say something")
    t = st.text_input("User statement", "I have a dog named Bruno.")
    if st.button("Add + consolidate"):
        s.observe(t); s.end_session(); st.rerun()
    st.subheader("Audit receipts")
    ok, idx, why = s.verify_receipts()
    st.write(f"chain valid: **{ok}** ({why})")
    st.json(s.fm.receipts.receipts[-1] if s.fm.receipts.receipts else {})
