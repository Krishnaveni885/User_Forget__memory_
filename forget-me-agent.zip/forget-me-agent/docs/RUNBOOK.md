# Runbook: what to do next on your machine (with network / API access)

1. `pip install -r requirements.txt && make test`  (28 tests, ~5 s)
2. `make example` reproduces the guide's section-5 example; `make ui` / `make api` start the demo.
3. **Real LLM**: `export ANTHROPIC_API_KEY=...` then in Python
   `hub = MemoryHub(backend=AnthropicBackend("claude-haiku-5-5"))` (or `OpenAICompatBackend("llama3.1")` for Ollama). Check the outputs by hand first.
   The adapters only replace parse / judge_contains / judge_leak; extraction, consolidation and answering in `agent.py` are still offline and should be swapped for an
   LLM-based writer (see TODO below) before claiming results on real memory systems.
4. **Real BEMULA**: `git clone https://github.com/Nboxff/bemula-benchmark`. Write an adapter (`ingest(turn)`, `query(q)`, `reset()`; BEMULA's C.1 protocol) around
   `MemoryHub` + `ForgetMe`, with a real LLM extractor that writes raw -> summary -> derived tiers with `parents`. Use BEMULA's judge and Score script so numbers are comparable.
5. **Mem0 baseline**: `pip install mem0ai`, wrap its `add/search/delete/update` in the same adapter; compare with `Mem0Style` in `bench/systems.py`.
6. **Judge validation**: `make judge`, hand-label `results/judge_labeling_sheet.csv` (column human_label 1/0), then
   `python -m bench.judge_validation --score results/judge_annotation_sheet.csv` -> agreement + Cohen's kappa (BEMULA reports 98% / 0.96 for its judge).
7. Re-run `make bench` with more seeds; keep fixed seeds; commit `results/`.
8. Every few weeks search arXiv/Google Scholar for "agent memory unlearning" / "agent memory deletion" and update related work.

TODO for a publishable version: LLM-based fact extraction and answering; BEMULA + Mem0 runs on >=2 real backbones; human-validated judge; stronger tombstone attacker (LLM);
real Hinglish/Telugu data; multi-agent via LangGraph.
