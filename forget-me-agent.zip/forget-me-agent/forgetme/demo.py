"""DemoSession: a hub with two agents + a conversation log, so a control agent (that never saw the target) can be built."""
from __future__ import annotations

from .agent import MemoryHub
from .config import ForgetConfig
from .models import TargetSpec
from .pipeline import ForgetMe, ForgetReport
from .provenance import ProvenanceGraph
from .receipts import verify_chain

SAMPLE = [
    "I was diagnosed with type 2 diabetes last year.", "I'm vegetarian, so no meat please.",
    "I live in Hyderabad, near Banjara Hills.", "I work as a data engineer at Infosys.",
    "I make about 18 lakh a year before tax.", "I had knee surgery in March 2024.",
    "I took a two-week trip to Japan in June 2024.", "I go cycling every weekend on the Hike and Bike trail.",
]


class DemoSession:
    def __init__(self, cfg: ForgetConfig | None = None, sample: bool = True, share_with_agent_b: bool = True):
        self.cfg = cfg or ForgetConfig()
        self.hub = MemoryHub(cfg=self.cfg)
        self.hub.agent("A"); self.hub.agent("B")
        self.fm = ForgetMe(self.hub, self.cfg)
        self.log: list[tuple[str, str]] = []          # (kind, text)
        if sample:
            for t in SAMPLE:
                self.observe(t)
            self.end_session()
            if share_with_agent_b:
                self.share()

    def observe(self, text: str):
        self.log.append(("user", text)); self.hub.agent("A").observe(text)

    def end_session(self):
        self.log.append(("end", "")); self.hub.agent("A").end_session()

    def share(self):
        ids = [m.id for m in self.hub.store.all(("live",), "A")]
        self.log.append(("share", "")); return self.hub.share("A", "B", ids)

    def build_control(self, target: TargetSpec):
        """Replay the conversation WITHOUT any turn that states/implies the target -> never saw the fact."""
        h = MemoryHub(cfg=ForgetConfig(use_guard=False, seed=1))
        h.agent("A"); h.agent("B")
        for kind, text in self.log:
            if kind == "user" and not self.hub.backend.judge_contains(text, target):
                h.agent("A").observe(text)
            elif kind == "end":
                h.agent("A").end_session()
        return h

    def forget(self, request: str, agent: str = "A") -> ForgetReport:
        parsed = self.hub.backend.parse_request(request)
        control = None
        if not parsed.needs_clarification:
            control = self.build_control(TargetSpec.from_parsed(parsed)).agent("A")
        return self.fm.forget(request, agent, control_agent=control, parsed=parsed)

    def memories(self):
        return [dict(id=m.id, agent=m.agent_id, tier=m.tier, parents=m.parents, text=m.text, status=m.status)
                for m in self.hub.store.all(("live", "tombstone"))]

    def graph(self):
        return ProvenanceGraph.from_store(self.hub.store)

    def ask(self, question: str, agent: str = "A"):
        a = self.hub.agent(agent).answer(question)
        return {"answer": a.text, "sources": a.sources}

    def verify_receipts(self):
        return verify_chain(self.fm.receipts.receipts, self.fm.receipts.public_key_pem)
