# Limitations and honesty notes (read before quoting any number)

1. **Offline backend.** The build environment had no LLM/API access. Parsing, the "does this contain or imply the target" judge, summarising and answering
   are implemented by a deterministic rule/lexicon backend (`forgetme/llm.py`, `forgetme/lexicon.py`). Real adapters exist
   (`AnthropicBackend`, `OpenAICompatBackend` for Ollama) and are unit-tested against a fake transport only. **They have never been run against a live model.**
2. **Synthetic, lexicon-generated benchmark.** The extension benchmark (`bench/synth.py`) is generated from the same lexicon the offline backend uses, so
   the offline NLU is, by construction, good at it. The results measure the architecture (provenance closure, cascade planning, guard, repair loop),
   not language understanding. **It is not BEMULA** and no BEMULA numbers have been produced. BEMULA's data/code (github.com/Nboxff/bemula-benchmark) were not
   reachable from the sandbox; `docs/RUNBOOK.md` says how to run on it.
3. **Baselines are re-implementations / simulations**: `PromptSuppress(sim)` (rule-based pretend LLM), `Mem0Style` (policy only), `SBUStyle` (idea only).
   None is the original library/paper code. Mem0 and LangGraph were not installed or used.
4. **"Second backbone" = second answerer profile** (`strict` vs `lenient` attack susceptibility). It is not a different LLM.
5. **Evaluator-side oracle.** Leakage uses alias matching plus a hidden lineage tag (`meta.roots`) that no system reads (enforced by a test). Residual-lineage and collateral counts in the results also use it.
6. **Verifier blind spot and a negative result.** Probes are text based. A leaked copy whose text carries no cue (a neutral depth-3 note whose provenance edge was lost) is invisible to the verifier and cannot be repaired. In the provenance-noise experiment the full system, `noRepair` and `noGuard` are **identical** (results/RESULTS.md): on this benchmark the repair loop and guard add nothing measurable, because the leaks left after edge loss are exactly the cue-free ones. They are shown to work only in unit tests where a leak is text-visible (`tests/test_core.py`). Do not claim a benchmark benefit for them without a better test (e.g. an LLM judge, or leaks that carry text cues).
7. **Tombstone study** uses rule-based attackers and an assumption about session coherence. Near-chance accuracy against them is not a proof of safety.
   A learned/LLM attacker is future work.
8. **Not legal compliance.** This measures technical leakage only. DPDP Act 2023 / Rules 2025 wording and dates must be checked at meity.gov.in; nothing here is legal advice.
9. **Judge validation**: no human labels exist yet. `bench/judge_validation.py` writes a 100-item sheet to label; only the judge-vs-oracle agreement is reported until then.
10. **Code-mixed (Hinglish / Telugu-English) requests** are my own romanised templates, not validated by native speakers; novelty of this angle is unchecked (the guide says to verify).
11. Shared-memory "sharing" is a simulated environment event (copy with cross-agent provenance edges), not LangGraph.
12. Not done: Chroma/FAISS/sentence-transformers integration (a hashing embedder and a NumPy index are used; `make_embedder("st")` is provided but untested), Neo4j, a real Mem0 run.
13. **Preservation is not discriminating.** PR and RLA are 100% for every system because the extractive answerer reads raw facts, which no system deletes unless targeted. Over-forgetting is visible only through the structural *collateral* count (unrelated memories lost, small for all systems), not through answers.
14. **Collateral** for ForgetMe (about 0.8% of unrelated memories) comes from re-derived summaries/notes whose wording changes; it is evaluator-side (hidden lineage) and not a BEMULA metric.
15. **Earlier results removed.** An earlier run's outputs whose generating code was replaced are kept in `results/_orphaned_earlier_run/` and `bench/_orphaned_earlier_run/` for reference only; nothing in README/RESULTS cites them.