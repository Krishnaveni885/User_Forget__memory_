import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import pytest
from forgetme.agent import MemoryHub
from forgetme.config import ForgetConfig
from forgetme.lexicon import CONCEPTS


def build_hub(concepts, cfg=None, db_path=":memory:", agents=("A",), share_to=None, variant=0):
    hub = MemoryHub(cfg=cfg or ForgetConfig(), db_path=db_path)
    a = hub.agent("A")
    for c in agents[1:]:
        hub.agent(c)
    for cid in concepts:
        a.observe(CONCEPTS[cid].utter[variant % len(CONCEPTS[cid].utter)], fact_id=f"f_{cid}")
        if cid in ("diabetes", "veg") or True:
            pass
    a.end_session()
    if share_to:
        hub.share("A", share_to, [m.id for m in hub.store.all(("live",), "A")])
    return hub


@pytest.fixture
def hub():
    return build_hub(["diabetes", "veg", "hyderabad", "salary", "knee", "run", "japan"])
