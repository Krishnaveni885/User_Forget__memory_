# One-page scope (Step 0 of the guide)

**Problem.** When a user asks an agent to forget a fact, copies survive in summaries, derived notes, vector-index entries, caches, other agents' memory and even in the deletion marker.
**Contributions chosen (3 of the 5 gaps in the guide):** (1) cross-agent erasure via provenance closure that crosses agents; (2) a reusable drop-in layer with a verify-and-repair loop and a read-time guard;
(3) leakage-safe tombstones + (4) a content-free, hash-chained verifiable receipt. The Hinglish/Telugu extension is included as an optional, unvalidated slice.
**Explicitly NOT doing:** model-weight unlearning; legal-compliance claims; claiming to be first (BEMULA, SBU, Secure Forgetting, Deployment-Time Memorization, Revoked-but-Still-Authoritative exist);
real personal data (all data is synthetic).
**Closest prior work:** BEMULA (benchmark, no fix), SBU (dependency closure, single-agent), Deployment-Time Memorization (summary-tier fidelity; re-summarise/purge/tombstone), Revoked-but-Still-Authoritative (read-time guard), Inference-Aware Deletion in DBs (deletion-pattern leakage).
