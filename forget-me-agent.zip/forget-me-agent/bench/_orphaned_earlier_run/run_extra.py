"""E8: unreliable 'contains/implies' judge (guard + repair loop value).  E9: what the verifier's probes detect per system.
   python -m bench.run_extra --out results"""
from __future__ import annotations

import argparse
import os
from concurrent.futures import ProcessPoolExecutor

import pandas as pd

from forgetme.lexicon import CONCEPTS, INFERENCES
from forgetme.models import TargetSpec
from forgetme.verifier import Verifier
from .run import run_grid, table
from .synth import generate_dataset
from .systems import REGISTRY, MAIN


def _verify_work(args):
    name, inst = args
    s = REGISTRY[name](seed=0, derive_depth=inst.derive_depth)
    s.play(inst, "forget")
    out = []
    for r in inst.requests:
        if r.kind == "F6":
            spec = TargetSpec(kind="replacement", concept_ids=r.target_concepts)
        elif r.kind == "F4":
            spec = TargetSpec(kind="inferential", inference_ids=[r.inference])
        else:
            spec = TargetSpec(kind="factual", concept_ids=r.target_concepts)
        rep = Verifier(s.hub, s.hub.cfg, None).verify(spec, "A")
        out.append(dict(system=name, leaks=rep.leaks_found, probe_leaks=sum(v["leaks"] for v in rep.by_style.values()),
                        bytes_hit=int(rep.bytes_hit), orphan=len(rep.orphan_vectors)))
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--out", default="results"); ap.add_argument("--workers", type=int, default=os.cpu_count())
    a = ap.parse_args()
    ds = {s: generate_dataset(60, s) for s in (0, 1)}
    specs = []
    for q in (0.0, 0.1, 0.2, 0.3, 0.5):
        for name in ("ForgetMe", "ForgetMe-noRepair", "ForgetMe-noGuard", "ForgetMe-noGuard-noRepair", "SBUStyle", "DeleteByID"):
            specs.append((f"{name} miss={q}", name, {"judge_miss": q}))
    table(run_grid(specs, ds, a.workers))[["Leakage", "ForgetSuccess", "FE", "AR", "Coverage", "Score"]].round(2).to_csv(f"{a.out}/E8_judge_noise.csv")
    d9 = generate_dataset(30, 0)
    rows = []
    with ProcessPoolExecutor(a.workers) as ex:
        for out in ex.map(_verify_work, [(n, i) for n in MAIN for i in d9], chunksize=4):
            rows += out
    df = pd.DataFrame(rows)
    g = df.groupby("system").agg(requests=("leaks", "size"), verifier_leak_rate=("leaks", lambda x: 100 * (x > 0).mean()),
                                 probe_leak_rate=("probe_leaks", lambda x: 100 * (x > 0).mean()),
                                 physical_residue_rate=("bytes_hit", lambda x: 100 * x.mean()))
    g = g.loc[[m for m in MAIN]]
    g.round(1).to_csv(f"{a.out}/E9_verifier_detection.csv")
    print(g.round(1))
