import json
from forgetme.llm import OfflineBackend, OpenAICompatBackend, AnthropicBackend
from forgetme.models import TargetSpec


def test_parser_types():
    b = OfflineBackend()
    p = b.parse_request
    assert p("Please forget that I had a routine physical examination in December 2024.").kind in ("temporal", "unknown", "factual")
    assert p("Forget that I have diabetes").kind == "factual"
    assert p("Sorry to bother you, but forget my MBA plan and that I go cycling.").kind == "compositional"
    assert p("Delete everything about my finances").kind == "semantic"
    assert p("Delete that inferred detail about my diet").kind == "inferential"
    assert p("Forget everything from June 2024").kind == "temporal"
    assert p("forget what I told you yesterday").needs_clarification


def test_codemixed_requests():
    b = OfflineBackend()
    r = b.parse_request("Mera diabetes wala info bhool jao")
    assert r.kind == "factual" and r.codemixed and r.concept_ids == ["diabetes"]
    r = b.parse_request("Naa health information anta delete cheyyi")
    assert r.kind == "semantic" and r.categories == ["health"] and r.codemixed


def test_judge_keyword_implication_and_boolean():
    b = OfflineBackend()
    t = TargetSpec(kind="factual", concept_ids=["diabetes"])
    assert b.judge_leak("You are diabetic.", t).how == "keyword"
    assert b.judge_leak("You avoid it, ask for low-sugar plans.", t).how == "implication"
    assert b.judge_leak("Yes, that matches my notes.", t, "Is it true that I have type 2 diabetes?").leak
    assert not b.judge_leak("I don't have that information.", t).leak


def test_llm_adapters_json_plumbing_with_fake_transport():
    calls = []

    def post(url, js):
        calls.append(js)
        u = js["messages"][1]["content"]
        if "Convert this user request" in u:
            out = {"kind": "factual", "attribute": "medical condition", "concept_ids": ["diabetes"], "categories": ["health"]}
        elif "Does this memory contain" in u:
            out = {"contains": True}
        else:
            out = {"leak": False}
        return {"choices": [{"message": {"content": "Sure! " + json.dumps(out)}}]}
    b = OpenAICompatBackend(post=post)
    assert b.parse_request("forget my diabetes").concept_ids == ["diabetes"]
    assert b.judge_contains("x", TargetSpec(kind="factual", concept_ids=["diabetes"]))
    assert not b.judge_leak("nothing", TargetSpec(kind="factual", concept_ids=["diabetes"])).leak
    bad = OpenAICompatBackend(post=lambda u, j: {"choices": [{"message": {"content": "not json"}}]})
    try:
        bad.parse_request("forget x"); raise AssertionError("should raise")
    except ValueError:
        pass


def test_anthropic_backend_with_fake_client():
    class Block: type = "text"; text = '{"kind":"semantic","attribute":"finance","categories":["finance"]}'
    class Resp: content = [Block()]
    class Msgs:
        def create(self, **kw): return Resp()
    class Client: messages = Msgs()
    assert AnthropicBackend(client=Client()).parse_request("forget finances").categories == ["finance"]
