"""Step 4: find all memories matching the target: (a) embedding candidates, (b) judge, (c) closure (planner)."""
from __future__ import annotations

from dataclasses import dataclass, field

from .config import ForgetConfig
from .lexicon import CATEGORY_LABEL, CATEGORY_CUES, CONCEPTS, INFERENCES
from .models import TargetSpec


@dataclass
class FindResult:
    matched: set[int] = field(default_factory=set)
    candidates: int = 0
    judged: int = 0


def target_queries(target: TargetSpec) -> list[str]:
    qs: list[str] = []
    for c in target.concept_ids:
        k = CONCEPTS[c]
        qs += [k.gist, k.fact, k.label, k.q_value] + k.aliases + k.implied[:2]
    for i in target.inference_ids:
        inf = INFERENCES[i]
        qs += [inf.text, inf.label, inf.q_value] + inf.aliases
    for cat in target.categories:
        if cat in CATEGORY_LABEL:
            qs.append(CATEGORY_LABEL[cat])
    return [q for q in dict.fromkeys(qs) if q]


def find_targets(hub, target: TargetSpec, cfg: ForgetConfig, agent_ids: list[str] | None = None) -> FindResult:
    res = FindResult()
    allowed_agents = set(agent_ids) if agent_ids else set(hub.agents) | {m for m in hub.owner.values()}
    live = {m.id: m for m in hub.store.all(("live", "archived")) if m.agent_id in allowed_agents}
    if target.kind == "temporal" and target.period:
        res.matched = {i for i, m in live.items() if m.meta.get("event_time") == target.period}
        res.candidates = res.judged = len(live)
        return res
    qs = target_queries(target)
    cand: set[int] = set()
    if qs:
        vecs = hub.embedder.embed(qs)
        for v in vecs:
            for i, _ in hub.index.search(v, k=cfg.candidate_k):
                if i in live:
                    cand.add(i)
    cand |= {i for i, m in live.items() if m.status == "archived"}      # cold-storage scan (no vectors to search)
    res.candidates = len(cand)
    for i in sorted(cand):
        res.judged += 1
        if hub.backend.judge_contains(live[i].text, target):
            res.matched.add(i)
    return res
