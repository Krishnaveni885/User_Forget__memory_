from __future__ import annotations
from dataclasses import dataclass, field, asdict


@dataclass
class ForgetConfig:
    """Switches for the full system and for ablations (see bench/systems.py)."""
    use_graph: bool = True            # follow provenance closure (descendants)
    cross_agent: bool = True          # closure + finder span all agents sharing memory
    use_guard: bool = True            # read-time blocklist (ids + hashed signatures)
    use_repair: bool = True           # verify -> trace leak -> re-plan loop
    use_verifier: bool = True         # run leak probes at all
    tombstone_style: str = "none"     # none | descriptive | generic | encrypted_log
    tombstone_scope: str = "linked"   # linked (only nodes with cross-agent links) | all
    compact_ids: bool = False         # renumber ids after deletion (hide id gaps)
    max_repair_rounds: int = 3
    probes_per_style: int = 2
    candidate_k: int = 40             # embedding candidates per query before the judge
    retrieval_k: int = 3
    guard_include_implied: bool = False
    physical_vacuum: bool = True
    archive_raw: bool = False         # compressed memory: raw facts move to cold storage (no vector), summaries carry them
    seed: int = 0

    def to_dict(self):
        return asdict(self)
