"""Provenance DAG (NetworkX) over the memory store: parent -> child edges."""
from __future__ import annotations

import random
import networkx as nx

from .store import MemoryStore


class ProvenanceGraph:
    def __init__(self, g: nx.DiGraph | None = None):
        self.g = g if g is not None else nx.DiGraph()

    @classmethod
    def from_store(cls, store: MemoryStore, cross_agent: bool = True) -> "ProvenanceGraph":
        g = nx.DiGraph()
        for m in store.all(statuses=("live", "archived", "tombstone", "deleted")):
            g.add_node(m.id, agent=m.agent_id, tier=m.tier)
        for p, c, x in store.edges():
            if p in g and c in g and (cross_agent or not x):
                g.add_edge(p, c, cross_agent=bool(x))
        return cls(g)

    def parents(self, n: int) -> list[int]:
        return sorted(self.g.predecessors(n)) if n in self.g else []

    def children(self, n: int) -> list[int]:
        return sorted(self.g.successors(n)) if n in self.g else []

    def descendants(self, n: int) -> set[int]:
        return nx.descendants(self.g, n) if n in self.g else set()

    def ancestors(self, n: int) -> set[int]:
        return nx.ancestors(self.g, n) if n in self.g else set()

    def closure(self, nodes) -> set[int]:
        """Dependency closure: the nodes plus everything derived from them (any depth, any agent)."""
        out = set(nodes)
        for n in list(nodes):
            out |= self.descendants(n)
        return out

    def topo(self, nodes) -> list[int]:
        nodes = set(nodes)
        return [n for n in nx.topological_sort(self.g) if n in nodes]

    def depth(self, n: int) -> int:
        a = self.ancestors(n)
        return 0 if not a else 1 + max(self.depth(p) for p in self.parents(n))

    def with_dropped_edges(self, p: float, rng: random.Random) -> "ProvenanceGraph":
        """Simulate incomplete provenance (missed links) for robustness experiments."""
        g = self.g.copy()
        for u, v in list(g.edges):
            if rng.random() < p:
                g.remove_edge(u, v)
        return ProvenanceGraph(g)
