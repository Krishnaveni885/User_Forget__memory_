"""Judge reliability.  (1) automatic self-check: text-only judge vs the lineage oracle.
(2) human protocol: writes a 100-item balanced sheet; fill `annotator` with correct/incorrect then
    python -m bench.judge_validation --score sheet.csv   -> agreement and Cohen's kappa."""
from __future__ import annotations

import argparse
import csv
import random

from forgetme.lexicon import CONCEPTS, INFERENCES
from forgetme.models import TargetSpec
from .metrics import lineage_leak
from .synth import generate_dataset
from .systems import DeleteByID, SBUStyle, ForgetMeSystem


def collect(n=30, seed=0):
    items = []
    for cls in (DeleteByID, SBUStyle, ForgetMeSystem):
        for inst in generate_dataset(n, seed):
            s = cls(inst.derive_depth, seed)
            for ev in inst.events:
                s.ingest(ev, "forget")
            req = {r.id: r for r in inst.requests}
            for q in inst.questions:
                if q.suite not in ("efficacy", "attack"):
                    continue
                r = req[q.req]
                if r.kind == "F6":
                    continue
                roots = set(r.target_facts)
                al = INFERENCES[r.inference].aliases if r.kind == "F4" else [a for c in r.target_concepts for a in CONCEPTS[c].aliases]
                tgt = TargetSpec(kind="inferential" if r.kind == "F4" else "factual",
                                 concept_ids=[] if r.kind == "F4" else r.target_concepts[:1],
                                 inference_ids=[r.inference] if r.kind == "F4" else [])
                ans = s.answer(q.text, q.agent)
                items.append({"system": cls.__name__, "question": q.text, "gold_aliases": "|".join(q.gold_any),
                              "answer": ans.text, "judge_leak": int(s.hub.backend.judge_leak(ans.text, tgt, q.text).leak),
                              "oracle_leak": int(lineage_leak(s, ans, roots, al))})
    return items


def kappa(a, b):
    n = len(a); po = sum(x == y for x, y in zip(a, b)) / n
    pa = sum(a) / n; pb = sum(b) / n
    pe = pa * pb + (1 - pa) * (1 - pb)
    return (po - pe) / (1 - pe) if pe < 1 else 1.0


def judge_report(out="results") -> str:
    items = collect()
    j = [i["judge_leak"] for i in items]; o = [i["oracle_leak"] for i in items]
    agree = sum(x == y for x, y in zip(j, o)) / len(items)
    fp = sum(1 for x, y in zip(j, o) if x and not y); fn = sum(1 for x, y in zip(j, o) if y and not x)
    rng = random.Random(0)
    pos = [i for i in items if i["judge_leak"]]; neg = [i for i in items if not i["judge_leak"]]
    sheet = rng.sample(pos, min(50, len(pos))) + rng.sample(neg, min(50, len(neg)))
    rng.shuffle(sheet)
    with open(f"{out}/judge_annotation_sheet.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["system", "question", "gold_aliases", "answer", "judge_leak", "annotator"])
        w.writeheader()
        for i in sheet:
            w.writerow({k: i[k] for k in ("system", "question", "gold_aliases", "answer", "judge_leak")} | {"annotator": ""})
    return (f"Text-only judge vs lineage oracle on {len(items)} efficacy/attack answers: agreement {100 * agree:.1f}%, "
            f"kappa {kappa(j, o):.2f}, judge false positives {fp}, false negatives {fn} "
            f"(false negatives are leaks through neutral derived notes that no text judge can see — the repair loop's blind spot). "
            f"A 100-item sheet for **human** annotation was written to `judge_annotation_sheet.csv`; no human labels exist yet.")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--score")
    a = ap.parse_args()
    if a.score:
        rows = list(csv.DictReader(open(a.score)))
        rows = [r for r in rows if r["annotator"].strip()]
        h = [1 if r["annotator"].strip().lower() in ("leak", "1", "yes", "correct") else 0 for r in rows]
        j = [int(r["judge_leak"]) for r in rows]
        print(f"n={len(rows)} agreement={sum(x == y for x, y in zip(h, j)) / len(rows):.3f} kappa={kappa(h, j):.2f}")
    else:
        print(judge_report("."))
