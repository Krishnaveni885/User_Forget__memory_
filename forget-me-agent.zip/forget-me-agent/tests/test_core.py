import os, tempfile
from conftest import build_hub
from forgetme.agent import MemoryHub
from forgetme.config import ForgetConfig
from forgetme.lexicon import CONCEPTS
from forgetme.pipeline import ForgetMe
from forgetme.provenance import ProvenanceGraph
from forgetme.vector_index import VectorIndex
import numpy as np


def texts(hub, agent=None):
    return " || ".join(m.text.lower() for m in hub.store.all(("live", "tombstone"), agent))


def test_vector_index_physical_delete():
    ix = VectorIndex(4)
    for i in range(5):
        ix.upsert(i, np.eye(4, dtype=np.float32)[i % 4] + i)
    assert ix.delete(2) and 2 not in ix and len(ix) == 4 and not ix.delete(2)
    assert all(i != 2 for i, _ in ix.search(np.ones(4), k=10))


def test_store_physical_delete_leaves_no_bytes():
    d = tempfile.mkdtemp()
    hub = build_hub(["diabetes", "veg"], db_path=os.path.join(d, "m.db"))
    assert b"diabet" in hub.store.raw_bytes().lower()
    ForgetMe(hub).forget("Forget that I have diabetes")
    assert b"diabet" not in hub.store.raw_bytes().lower()          # VACUUM + secure_delete


def test_provenance_closure_and_cross_agent():
    hub = build_hub(["diabetes", "veg"], agents=("A", "B"), share_to="B")
    g = ProvenanceGraph.from_store(hub.store)
    raw = next(m for m in hub.store.all() if m.agent_id == "A" and m.tier == "raw" and "diabet" in m.text.lower())
    clo = g.closure([raw.id])
    assert any(hub.store.get(i).agent_id == "B" for i in clo)      # crosses agents
    g2 = ProvenanceGraph.from_store(hub.store, cross_agent=False)
    assert all(hub.store.get(i).agent_id == "A" for i in g2.closure([raw.id]))


def test_guide_example_delete_rewrite_keep(hub):
    before = {m.id: m for m in hub.store.all()}
    rep = ForgetMe(hub).forget("Forget that I have diabetes")
    assert rep.status == "done" and rep.leak_test["leaks_found"] == 0
    live = texts(hub)
    assert "diabet" not in live and "low-sugar" not in live
    # unrelated memory kept, mixed summary rewritten (not deleted) -> no over-forgetting
    assert "vegetarian" in live and "hyderabad" in live
    assert rep.rewritten, "mixed summary should be re-derived"
    summ = [m for m in hub.store.all() if m.tier == "summary"]
    assert summ and all("diabet" not in m.text.lower() for m in summ)
    assert rep.index_entries_removed >= 1
    assert all(i not in hub.index for i in rep.deleted)
    assert set(hub.index.ids) <= hub.store.ids(("live",))          # no orphan vectors
    assert rep.receipt_hash.startswith("sha256:")


def test_over_forgetting_vs_delete_by_id(hub):
    n_before = hub.store.count()
    ForgetMe(hub).forget("Forget that I have diabetes")
    unrelated = [m for m in hub.store.all(("live",)) if m.tier == "raw"]
    assert {"veg", "hyderabad", "salary", "knee", "run", "japan"} == {m.meta["concept"] for m in unrelated}


def test_semantic_category_f3(hub):
    rep = ForgetMe(hub).forget("Don't store any of my financial information. Delete everything in that category.")
    assert rep.kind == "semantic"
    assert "18 lakh" not in texts(hub) and "tax slab" not in texts(hub)
    assert "diabet" in texts(hub)                                   # other categories untouched


def test_inferential_f4_keeps_sources_and_blocks_rederivation(hub):
    assert "diabetic vegetarian diet" in texts(hub)
    rep = ForgetMe(hub).forget("Delete that inferred detail about my diet immediately.")
    assert rep.kind == "inferential"
    live = texts(hub)
    assert "diabetic vegetarian diet" not in live
    assert "type 2 diabetes" in live and "vegetarian" in live      # sources are preserved
    hub.agent("A").observe("I'm vegetarian, so no meat please.")    # new evidence arrives
    hub.agent("A").end_session()
    assert "diabetic vegetarian diet" not in texts(hub)             # suppression registry prevents re-derivation


def test_temporal_f5(hub):
    rep = ForgetMe(hub).forget("I've completely moved on from everything around June 2024, forget those days.")
    assert rep.kind == "temporal"
    assert "japan" not in texts(hub) and "knee surgery" in texts(hub)


def test_replacement_f6():
    hub = build_hub(["italian", "run"])
    ForgetMe(hub).forget("Please forget that I used to love Italian food, now I am vegetarian, so only remember that.")
    assert "italian" not in texts(hub) and "pasta" not in texts(hub)


def test_clarification_for_vague_request(hub):
    n = hub.store.count()
    rep = ForgetMe(hub).forget("forget what I told you yesterday")
    assert rep.status == "needs_clarification" and rep.clarifying_question
    assert hub.store.count() == n                                   # nothing touched


def test_multi_agent_erasure():
    hub = build_hub(["diabetes", "veg"], agents=("A", "B"), share_to="B")
    assert "diabet" in texts(hub, "B")
    rep = ForgetMe(hub).forget("Forget that I have diabetes")
    assert "diabet" not in texts(hub, "B") and rep.leak_test["leaks_found"] == 0
    # without cross-agent closure the copy in B survives
    hub2 = build_hub(["diabetes", "veg"], cfg=ForgetConfig(cross_agent=False), agents=("A", "B"), share_to="B")
    ForgetMe(hub2).forget("Forget that I have diabetes")
    assert "diabet" in texts(hub2, "B")


def test_stale_cache_cleared_and_guard_is_safety_net(hub):
    a = hub.agent("A")
    q = "What chronic medical condition was I diagnosed with?"
    assert "diabet" in a.answer(q).text.lower()                     # populates cache
    ForgetMe(hub).forget("Forget that I have diabetes")
    assert not a.cache or all("diabet" not in t.lower() for rows in a.cache.values() for _, t, _, _ in rows)
    assert "diabet" not in a.answer(q).text.lower()


def test_guard_blocks_missed_copy_but_allows_relearning(hub):
    ForgetMe(hub).forget("Forget that I have diabetes")
    # a copy slips in with an OLD timestamp (e.g. restored from backup)
    mid = hub.store.add("Reminder: user is diabetic", "derived", "A", created_at=0.5, meta={"gist": "x"})
    hub.owner[mid] = "A"
    hub.index.upsert(mid, hub.embedder.embed(["Reminder: user is diabetic"])[0])
    a = hub.agent("A")
    assert "diabet" not in a.answer("Do I have diabetes?").text.lower()          # guard blocks
    hub.cfg.use_guard = False
    a.cache.clear()
    assert "diabet" in a.answer("Do I have diabetes?").text.lower()             # ...and only the guard did
    hub.cfg.use_guard = True
    # user restates the fact later -> new consent, not blocked
    a.observe("I was diagnosed with type 2 diabetes again this month.")
    a.cache.clear()
    assert "diabet" in a.answer("What chronic medical condition was I diagnosed with?").text.lower()


def test_repair_loop_catches_copy_the_finder_missed():
    def scenario(use_repair):
        cfg = ForgetConfig(candidate_k=1, use_repair=use_repair)
        hub = build_hub(["diabetes", "veg"], cfg=cfg)
        for i in range(3):   # unlinked stray copies (no provenance edges), invisible to a 1-candidate finder
            t = f"Reminder {i}: patient is diabetic, check sugar"
            m = hub.add_memory(t, "derived", "A", meta={"gist": t})
        rep = ForgetMe(hub, cfg).forget("Forget that I have diabetes")
        return rep, hub
    rep0, _ = scenario(False)
    assert rep0.leak_test["leaks_found"] > 0                       # one-shot deletion leaves leaks...
    assert rep0.leak_test["guarded_leaks_found"] == 0              # ...which the read guard hides from users (safety net, not a fix)
    rep1, hub1 = scenario(True)
    assert rep1.leak_test["leaks_found"] == 0 and rep1.repair_rounds >= 2   # ...the loop finds and removes them
    assert "diabet" not in texts(hub1)


def test_core_logic_never_reads_evaluator_lineage():
    root = os.path.join(os.path.dirname(__file__), "..", "forgetme")
    for f in ("finder.py", "planner.py", "verifier.py", "pipeline.py", "guard.py", "llm.py", "parser.py"):
        p = os.path.join(root, f)
        if os.path.exists(p):
            assert "roots" not in open(p).read(), f
