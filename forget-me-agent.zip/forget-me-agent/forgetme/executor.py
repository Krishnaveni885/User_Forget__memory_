"""Step 6: apply the plan to store + vector index + caches + other agents. Logical AND physical AND semantic."""
from __future__ import annotations

from dataclasses import dataclass, field

from .config import ForgetConfig
from .models import TargetSpec
from .planner import Plan
from .tombstones import AuditVault, make_marker


@dataclass
class ExecResult:
    purged: list[int] = field(default_factory=list)
    rewritten: list[dict] = field(default_factory=list)
    tombstoned: list[int] = field(default_factory=list)
    kept: list[int] = field(default_factory=list)
    index_entries_removed: int = 0
    caches_cleared: int = 0
    agents_notified: list[str] = field(default_factory=list)
    mapping: dict[int, int] | None = None


def execute(hub, plan: Plan, target: TargetSpec, cfg: ForgetConfig, vault: AuditVault | None = None,
            request_id: str = "") -> ExecResult:
    res = ExecResult(kept=sorted(plan.kept))
    st = hub.store
    # 1) guard first: even if a later step fails, reads are already blocked. No plaintext is stored.
    if cfg.use_guard:
        hub.guard.block_ids(set(plan.ids('purge')) | set(plan.ids('tombstone')))   # rewritten (re-derived) nodes stay readable
        terms = target.alias_terms(include_implied=cfg.guard_include_implied)
        hub.guard.add_signature(terms, hub.clock)
    if target.kind == "inferential":
        from .guard import signature_of_terms
        hub.suppressed.append(frozenset(signature_of_terms(target.alias_terms(), hub.key)))   # never re-derive

    # 2) rewrites first (topological order == ascending creation order for parents)
    for n in sorted(plan.ids("rederive")):
        a = plan.actions[n]
        m = st.get(n)
        parents = [p for p in m.parents if p not in plan.all_ids or plan.actions[p].kind == "rederive"]
        roots = sorted({r for p in parents if (pm := st.get(p)) for r in pm.meta.get("roots", [])})
        st.update_text(n, a.new_text, {"gist": a.new_text, "roots": roots})
        hub.reindex(n)
        res.rewritten.append({"id": n, "new_text": a.new_text})

    # 3) tombstones / purges
    for n in plan.ids("tombstone"):
        marker = make_marker(cfg.tombstone_style, target) or "[removed]"
        if hub.index.delete(n):
            res.index_entries_removed += 1
        st.tombstone(n, marker)
        res.tombstoned.append(n)
    purge = plan.ids("purge")
    for n in purge:
        if hub.index.delete(n):
            res.index_entries_removed += 1
        hub.owner.pop(n, None)
    st.delete(purge, vacuum=cfg.physical_vacuum)
    res.purged = purge
    if cfg.tombstone_style == "encrypted_log" and vault is not None:
        vault.record(request_id, target, len(purge) + len(res.tombstoned))

    # 4) caches, conversation context, other agents sharing the memory
    gone = set(purge) | set(res.tombstoned) | {r["id"] for r in res.rewritten}
    for ag in hub.agents.values():
        res.caches_cleared += ag.on_forget(gone, hub.guard if cfg.use_guard else None)
        res.agents_notified.append(ag.agent_id)

    if cfg.compact_ids:
        res.mapping = hub.compact()
    return res
