"""Tombstone styles (step 10) and the encrypted audit vault.

none          : row physically removed, nothing left in the live store
descriptive   : "[removed: medical condition]"   (leaks the category - the deletion pattern itself)
generic       : "[removed]"                      (hides the category, still reveals that/where something was removed)
encrypted_log : live store has nothing; a separate Fernet-encrypted log records what was removed
"""
from __future__ import annotations

import json
import os
import time

from cryptography.fernet import Fernet

from .lexicon import CATEGORY_LABEL
from .models import TargetSpec

STYLES = ("none", "descriptive", "generic", "encrypted_log")


def make_marker(style: str, target: TargetSpec, label: str | None = None) -> str | None:
    if style == "descriptive":
        lab = label or (target.labels()[0] if target.labels() else
                        CATEGORY_LABEL.get((target.categories or ["other"])[0], "personal information"))
        return f"[removed: {lab}]"
    if style == "generic":
        return "[removed]"
    return None


class AuditVault:
    """Encrypted record of deletions, kept OUTSIDE the live memory store. Key is held by the operator/auditor."""

    def __init__(self, key: bytes | None = None, path: str | None = None):
        self.key = key or Fernet.generate_key()
        self._f = Fernet(self.key)
        self.path = path
        self.records: list[bytes] = []

    def record(self, request_id: str, target: TargetSpec, n_nodes: int):
        payload = json.dumps({"request_id": request_id, "ts": time.time(), "labels": target.labels(),
                              "categories": target.primary_categories(), "n_nodes": n_nodes}).encode()
        tok = self._f.encrypt(payload)
        self.records.append(tok)
        if self.path:
            os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
            with open(self.path, "ab") as fh:
                fh.write(tok + b"\n")

    def decrypt_all(self, key: bytes | None = None) -> list[dict]:
        f = Fernet(key) if key else self._f
        return [json.loads(f.decrypt(t)) for t in self.records]
