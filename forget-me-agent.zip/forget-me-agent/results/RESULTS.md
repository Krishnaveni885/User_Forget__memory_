# Results (auto-generated)

Offline deterministic backend; synthetic extension set: 60 instances x seeds [0, 1, 2]. **These numbers measure the architecture on a lexicon-generated benchmark, not LLM behaviour and not the public BEMULA benchmark.** See docs/LIMITATIONS.md.


## Main comparison and ablations — answerer profile `lenient`

Mean±std over seeds (percent). Leakage = share of efficacy+attack probes revealing the target (lineage oracle). Residual lineage = live memories still descending from a target fact. Collateral = unrelated memories lost.

| System | FE | AR | PR | RLA | RPR | Score | Score 95% CI | Leakage% | Residual lineage | Collateral | s/forget | tok/forget |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| NoDeletion | 7.3±0.6 | 0.0±0.0 | 100.0±0.0 | 100.0±0.0 | 0.0±0.0 | 0.0±0.0 | [0.0, 0.0] | 98.4 | 5433/5405 | 0/14188 | 0.0001 | 0 |
| LogicalOnly | 59.6±0.8 | 47.1±0.9 | 100.0±0.0 | 100.0±0.0 | 30.7±2.5 | 53.0±0.8 | [49.7, 56.1] | 47.0 | 3096/5405 | 5/14188 | 0.0088 | 257 |
| DeleteByID | 59.6±0.8 | 47.1±0.9 | 100.0±0.0 | 100.0±0.0 | 30.7±2.5 | 53.0±0.9 | [49.7, 56.1] | 47.1 | 3096/5405 | 5/14188 | 0.0100 | 259 |
| PromptSuppress(sim) | 7.3±0.6 | 16.2±0.3 | 100.0±0.0 | 100.0±0.0 | 0.0±0.0 | 10.9±0.3 | [9.7, 12.3] | 84.6 | 5433/5405 | 0/14188 | 0.0003 | 16 |
| Mem0Style(sim) | 8.5±0.1 | 0.3±0.2 | 100.0±0.0 | 100.0±0.0 | 0.0±0.0 | 1.3±0.9 | [0.9, 2.3] | 97.9 | 5039/5405 | 0/14188 | 0.0019 | 23 |
| SBUStyle(sim) | 73.7±1.2 | 64.4±1.1 | 100.0±0.0 | 100.0±0.0 | 54.4±1.9 | 68.9±1.1 | [65.6, 72.5] | 29.3 | 1568/5405 | 7/14188 | 0.0149 | 251 |
| ForgetMe-full | 96.0±0.3 | 91.7±0.7 | 100.0±0.0 | 100.0±0.0 | 79.3±1.9 | 93.8±0.5 | [92.8, 94.8] | 0.5 | 0/5405 | 117/14188 | 0.1327 | 4186 |
| ForgetMe-noGuard | 96.0±0.3 | 91.7±0.7 | 100.0±0.0 | 100.0±0.0 | 79.3±1.9 | 93.8±0.5 | [92.8, 94.8] | 0.5 | 0/5405 | 117/14188 | 0.0765 | 4186 |
| ForgetMe-noRepair | 96.0±0.3 | 91.7±0.7 | 100.0±0.0 | 100.0±0.0 | 79.3±1.9 | 93.8±0.5 | [92.8, 94.8] | 0.5 | 0/5405 | 117/14188 | 0.1337 | 4186 |
| ForgetMe-noGraph | 78.0±1.4 | 68.7±0.9 | 100.0±0.0 | 100.0±0.0 | 43.7±1.3 | 73.2±1.1 | [70.2, 76.2] | 23.9 | 2134/5405 | 63/14188 | 0.1254 | 4097 |
| ForgetMe-noCrossAgent | 82.7±1.2 | 71.3±2.0 | 100.0±0.0 | 100.0±0.0 | 56.7±2.6 | 76.8±1.6 | [73.7, 79.3] | 21.3 | 1588/5405 | 110/14188 | 0.1067 | 3982 |
| ForgetMe-noVerifier | 96.0±0.3 | 91.7±0.7 | 100.0±0.0 | 100.0±0.0 | 79.3±1.9 | 93.8±0.5 | [92.8, 94.8] | 0.5 | 0/5405 | 117/14188 | 0.0269 | 413 |

## Main comparison and ablations — answerer profile `strict`

Mean±std over seeds (percent). Leakage = share of efficacy+attack probes revealing the target (lineage oracle). Residual lineage = live memories still descending from a target fact. Collateral = unrelated memories lost.

| System | FE | AR | PR | RLA | RPR | Score | Score 95% CI | Leakage% | Residual lineage | Collateral | s/forget | tok/forget |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| NoDeletion | 7.3±0.6 | 0.0±0.0 | 100.0±0.0 | 100.0±0.0 | 0.0±0.0 | 0.0±0.0 | [0.0, 0.0] | 98.4 | 5433/5405 | 0/14188 | 0.0000 | 0 |
| LogicalOnly | 59.6±0.8 | 51.9±1.6 | 100.0±0.0 | 100.0±0.0 | 34.1±2.4 | 55.6±1.2 | [51.8, 58.8] | 41.3 | 3096/5405 | 5/14188 | 0.0096 | 257 |
| DeleteByID | 59.6±0.8 | 51.9±1.6 | 100.0±0.0 | 100.0±0.0 | 34.1±2.4 | 55.6±1.2 | [51.8, 58.8] | 41.3 | 3096/5405 | 5/14188 | 0.0099 | 259 |
| PromptSuppress(sim) | 7.3±0.6 | 16.2±0.3 | 100.0±0.0 | 100.0±0.0 | 0.0±0.0 | 10.9±0.3 | [9.7, 12.3] | 84.2 | 5433/5405 | 0/14188 | 0.0005 | 16 |
| Mem0Style(sim) | 8.5±0.1 | 2.8±0.7 | 100.0±0.0 | 100.0±0.0 | 0.0±0.0 | 4.9±0.6 | [4.1, 5.8] | 95.6 | 5039/5405 | 0/14188 | 0.0018 | 23 |
| SBUStyle(sim) | 73.7±1.2 | 62.7±1.0 | 100.0±0.0 | 100.0±0.0 | 49.4±1.0 | 68.0±1.1 | [64.7, 71.6] | 28.7 | 1568/5405 | 7/14188 | 0.0147 | 251 |
| ForgetMe-full | 96.0±0.3 | 88.4±0.3 | 100.0±0.0 | 100.0±0.0 | 67.4±2.3 | 92.1±0.3 | [90.9, 93.3] | 0.4 | 0/5405 | 117/14188 | 0.1198 | 3163 |
| ForgetMe-noGuard | 96.0±0.3 | 88.4±0.3 | 100.0±0.0 | 100.0±0.0 | 67.4±2.3 | 92.1±0.3 | [90.9, 93.3] | 0.4 | 0/5405 | 117/14188 | 0.0736 | 3163 |
| ForgetMe-noRepair | 96.0±0.3 | 88.4±0.3 | 100.0±0.0 | 100.0±0.0 | 67.4±2.3 | 92.1±0.3 | [90.9, 93.3] | 0.4 | 0/5405 | 117/14188 | 0.1205 | 3163 |
| ForgetMe-noGraph | 78.0±1.4 | 73.9±0.9 | 100.0±0.0 | 100.0±0.0 | 47.5±2.2 | 75.9±1.1 | [73.1, 78.8] | 17.1 | 2134/5405 | 63/14188 | 0.1129 | 3106 |
| ForgetMe-noCrossAgent | 82.7±1.2 | 71.0±1.2 | 100.0±0.0 | 100.0±0.0 | 51.7±1.3 | 76.6±1.2 | [73.7, 79.3] | 19.2 | 1588/5405 | 110/14188 | 0.1003 | 2976 |
| ForgetMe-noVerifier | 96.0±0.3 | 88.4±0.3 | 100.0±0.0 | 100.0±0.0 | 67.4±2.3 | 92.1±0.3 | [90.9, 93.3] | 0.4 | 0/5405 | 117/14188 | 0.0263 | 413 |

## Non-leak rate by request type (higher is better; efficacy+attack items)

| System | F1 | F2 | F3 | F4 | F5 | F6 |
|---|---|---|---|---|---|---|
| NoDeletion | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 9.1 |
| DeleteByID | 65.4 | 68.4 | 64.7 | 2.2 | 3.1 | 66.5 |
| SBUStyle(sim) | 69.6 | 77.3 | 73.8 | 2.2 | 73.2 | 72.8 |
| ForgetMe-noGraph | 93.3 | 88.9 | 88.0 | 100.0 | 5.1 | 92.0 |
| ForgetMe-noCrossAgent | 75.8 | 82.7 | 77.8 | 100.0 | 73.2 | 78.9 |
| ForgetMe-full | 99.3 | 100.0 | 99.2 | 100.0 | 100.0 | 99.2 |

## Non-leak rate on extension slices (the cases BEMULA does not cover)

| System | single-agent | multi-agent | depth 1 | depth 3 | English | code-mixed |
|---|---|---|---|---|---|---|
| NoDeletion | 2.0 | 1.1 | 1.8 | 1.5 | 2.2 | 0.0 |
| DeleteByID | 69.8 | 37.8 | 54.3 | 49.7 | 54.1 | 49.9 |
| SBUStyle(sim) | 93.9 | 49.9 | 67.3 | 71.1 | 70.6 | 71.0 |
| ForgetMe-noGraph | 75.6 | 76.6 | 82.8 | 71.2 | 78.1 | 70.9 |
| ForgetMe-noCrossAgent | 99.7 | 59.8 | 74.7 | 78.9 | 78.8 | 78.4 |
| ForgetMe-full | 99.7 | 99.4 | 100.0 | 99.4 | 99.6 | 99.5 |

## Robustness to incomplete provenance (fraction of edges dropped)

| edge_drop | System | Leakage% | AR | Score | Residual lineage | resid_frac |
|---|---|---|---|---|---|---|
| 0.0 | ForgetMe-full | 0.0 | 89.7 | 93.4 | 0/1452 | 0.0% |
| 0.0 | ForgetMe-noRepair | 0.0 | 89.7 | 93.4 | 0/1452 | 0.0% |
| 0.0 | ForgetMe-noGuard | 0.0 | 89.7 | 93.4 | 0/1452 | 0.0% |
| 0.0 | ForgetMe-noGraph | 25.7 | 64.8 | 71.5 | 612/1452 | 42.1% |
| 0.1 | ForgetMe-full | 5.4 | 84.5 | 88.8 | 109/1452 | 7.5% |
| 0.1 | ForgetMe-noRepair | 5.4 | 84.5 | 88.8 | 109/1452 | 7.5% |
| 0.1 | ForgetMe-noGuard | 5.4 | 84.5 | 88.8 | 109/1452 | 7.5% |
| 0.1 | ForgetMe-noGraph | 25.7 | 64.8 | 71.5 | 612/1452 | 42.1% |
| 0.3 | ForgetMe-full | 11.9 | 78.4 | 83.1 | 274/1452 | 18.9% |
| 0.3 | ForgetMe-noRepair | 11.9 | 78.4 | 83.1 | 274/1452 | 18.9% |
| 0.3 | ForgetMe-noGuard | 11.9 | 78.4 | 83.1 | 274/1452 | 18.9% |
| 0.3 | ForgetMe-noGraph | 25.7 | 64.8 | 71.5 | 612/1452 | 42.1% |
| 0.5 | ForgetMe-full | 19.3 | 71.0 | 77.1 | 401/1452 | 27.6% |
| 0.5 | ForgetMe-noRepair | 19.3 | 71.0 | 77.1 | 401/1452 | 27.6% |
| 0.5 | ForgetMe-noGuard | 19.3 | 71.0 | 77.1 | 401/1452 | 27.6% |
| 0.5 | ForgetMe-noGraph | 25.7 | 64.8 | 71.5 | 612/1452 | 42.1% |
| 0.8 | ForgetMe-full | 22.2 | 68.4 | 74.3 | 540/1452 | 37.2% |
| 0.8 | ForgetMe-noRepair | 22.2 | 68.4 | 74.3 | 540/1452 | 37.2% |
| 0.8 | ForgetMe-noGuard | 22.2 | 68.4 | 74.3 | 540/1452 | 37.2% |
| 0.8 | ForgetMe-noGraph | 25.7 | 64.8 | 71.5 | 612/1452 | 42.1% |

## Tombstone leakage study

Attacker accuracy at guessing the deleted fact's **category** from what is left behind (chance = 8.3%). `coherence` = probability that adjacent facts share a category (an assumption).

| coherence | style | marker | neighbour | combined | chance | trials |
|---|---|---|---|---|---|---|
| 0.0 | none | 0.0% | 6.0% | 6.5% | 8.3% | 400 |
| 0.0 | descriptive | 100.0% | 7.0% | 100.0% | 8.3% | 400 |
| 0.0 | generic | 0.0% | 6.2% | 6.2% | 8.3% | 400 |
| 0.0 | encrypted_log | 0.0% | 5.0% | 5.2% | 8.3% | 400 |
| 0.0 | encrypted_log+compact_ids | 0.0% | 0.0% | 10.0% | 8.3% | 400 |
| 0.7 | none | 0.0% | 21.2% | 21.5% | 8.3% | 400 |
| 0.7 | descriptive | 100.0% | 19.0% | 100.0% | 8.3% | 400 |
| 0.7 | generic | 0.0% | 20.5% | 20.5% | 8.3% | 400 |
| 0.7 | encrypted_log | 0.0% | 19.8% | 20.2% | 8.3% | 400 |
| 0.7 | encrypted_log+compact_ids | 0.0% | 0.0% | 6.2% | 8.3% | 400 |

## Judge reliability (self-check, not a human study)

Text-only judge vs lineage oracle on 1386 efficacy/attack answers: agreement 89.2%, kappa 0.72, judge false positives 130, false negatives 20 (false negatives are leaks through neutral derived notes that no text judge can see — the repair loop's blind spot). A 100-item sheet for **human** annotation was written to `judge_annotation_sheet.csv`; no human labels exist yet.
