"""Step 5: choose purge / re-derive / tombstone per affected memory (avoids over-forgetting)."""
from __future__ import annotations

from dataclasses import dataclass, field

from .config import ForgetConfig
from .models import TargetSpec
from .provenance import ProvenanceGraph


@dataclass
class Action:
    kind: str                     # purge | rederive | tombstone
    reason: str
    new_text: str | None = None


@dataclass
class Plan:
    actions: dict[int, Action] = field(default_factory=dict)
    matched: set[int] = field(default_factory=set)
    kept: set[int] = field(default_factory=set)       # related memories deliberately preserved

    def ids(self, kind: str) -> list[int]:
        return sorted(i for i, a in self.actions.items() if a.kind == kind)

    @property
    def all_ids(self) -> set[int]:
        return set(self.actions)


def plan_cascade(graph: ProvenanceGraph | None, store, matched: set[int], target: TargetSpec,
                 cfg: ForgetConfig, backend) -> Plan:
    plan = Plan(matched=set(matched))
    live = {m.id: m for m in store.all(("live", "archived"))}
    matched = {i for i in matched if i in live}

    if graph is None or not cfg.use_graph:
        for i in matched:
            plan.actions[i] = Action("purge", "matched (no provenance graph)")
        return plan

    affected = {i for i in graph.closure(matched) if i in live}
    removed: set[int] = set()
    newgist: dict[int, str] = {}
    inferential = target.kind == "inferential"

    for n in graph.topo(affected):
        m = live[n]
        survivors = [p for p in graph.parents(n) if p in live and p not in removed]
        is_matched = n in matched
        if not graph.parents(n):
            plan.actions[n] = Action("purge", "matched root fact")
            removed.add(n); continue
        if not survivors:
            plan.actions[n] = Action("purge", "exists only because of the target")
            removed.add(n); continue
        if is_matched and inferential and m.tier == "derived":
            plan.actions[n] = Action("purge", "the derivation itself is the target")
            removed.add(n); continue
        if not any(p not in affected for p in survivors):
            plan.actions[n] = Action("purge", "depends only on content that changed")
            removed.add(n); continue
        gists = [newgist.get(p) or live[p].gist for p in survivors]
        new_text = backend.summarize(gists, tier=m.tier)
        if backend.judge_contains(new_text, target):
            plan.actions[n] = Action("purge", "re-derivation would still contain the target")
            removed.add(n); continue
        plan.actions[n] = Action("rederive", "mixes target with unrelated facts" if is_matched else
                                 "derived from a rewritten/removed parent", new_text)
        newgist[n] = new_text
        plan.kept |= {p for p in survivors if p not in affected}

    # tombstone: directly matched, purged nodes whose links must stay intact (children survive) or scope=all
    if cfg.tombstone_style in ("descriptive", "generic"):
        for n in list(plan.actions):
            a = plan.actions[n]
            if a.kind != "purge" or n not in matched:
                continue
            linked = any(c in live and c not in removed for c in graph.children(n))
            cross = any(graph.g.edges[n, c].get("cross_agent") for c in graph.children(n))
            if cfg.tombstone_scope == "all" or linked or cross:
                plan.actions[n] = Action("tombstone", "links must stay intact")
    return plan
