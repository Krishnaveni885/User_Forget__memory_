# Paper outline (guide section 13) — fill with numbers you have actually measured

1. **Abstract** — problem (hidden copies after a forget request), method (provenance closure, per-node purge/re-derive/tombstone, verify-and-repair, guard, receipts), measured results (state only what results/RESULTS.md shows).
2. **Introduction** — assistants keep long-term memory; BEMULA shows mainstream systems fail; DPDP Act 2023 s.12 right to erasure (check wording and dates at meity.gov.in; not legal advice).
3. **Related work** — BEMULA, SBU (backflow, dependency closure), Secure Forgetting, Deployment-Time Memorization, Revoked-but-Still-Authoritative, Inference-Aware Deletion in Databases. Do **not** claim to be first.
4. **Threat model** — attacker may ask direct / indirect / inference / adversarial questions, use a keyword search tool, ask another agent, or inspect leftover markers and id gaps.
5. **Method** — Steps 2-11 (modules in README table). Contribution candidates: cross-agent closure, verifiable content-free receipt, leakage-safe tombstones.
6. **Experiments** — synthetic extension set (deep chains, shared memory, code-mixed); BEMULA metrics; baselines; ablations; provenance-noise sweep; tombstone attacker study. **To do for a real paper:** run on the public BEMULA data with real LLM backbones (>= 2), a real Mem0 baseline, a human-validated judge.
7. **Results and ablations** — copy tables from results/RESULTS.md; include the negative result on guard/repair.
8. **Limitations** — docs/LIMITATIONS.md.
9. **Ethics** — synthetic data only; technical leakage measured, no compliance claim.
10. **Conclusion**.

Resume lines (use only after you re-measure on your own runs): "Built a provenance-tracked memory-erasure layer; on a synthetic benchmark reduced probe leakage from 47% (delete-by-ID) to 0.5% with no measured loss of unrelated-fact retrieval"; "Showed descriptive tombstones reveal the deleted category to a simple attacker 100% of the time vs chance for encrypted-log + id compaction".
