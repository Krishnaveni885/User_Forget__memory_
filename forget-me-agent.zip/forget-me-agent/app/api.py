"""FastAPI demo API.   uvicorn app.api:app --reload"""
from __future__ import annotations

import uuid

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from forgetme.config import ForgetConfig
from forgetme.demo import DemoSession

app = FastAPI(title="Forget-Me Agent", version="1.0")
SESSIONS: dict[str, DemoSession] = {}


class NewSession(BaseModel):
    sample: bool = True
    tombstone_style: str = "none"
    use_guard: bool = True
    use_repair: bool = True
    use_graph: bool = True


class Say(BaseModel):
    text: str


class Forget(BaseModel):
    request: str
    agent: str = "A"


class Ask(BaseModel):
    question: str
    agent: str = "A"


def _s(sid) -> DemoSession:
    if sid not in SESSIONS:
        raise HTTPException(404, "unknown session")
    return SESSIONS[sid]


@app.post("/sessions")
def new_session(b: NewSession):
    sid = uuid.uuid4().hex[:8]
    SESSIONS[sid] = DemoSession(ForgetConfig(tombstone_style=b.tombstone_style, use_guard=b.use_guard,
                                             use_repair=b.use_repair, use_graph=b.use_graph), sample=b.sample)
    return {"session": sid}


@app.post("/sessions/{sid}/say")
def say(sid: str, b: Say):
    s = _s(sid); s.observe(b.text); return {"ok": True}


@app.post("/sessions/{sid}/end")
def end(sid: str):
    _s(sid).end_session(); return {"ok": True}


@app.post("/sessions/{sid}/share")
def share(sid: str):
    return {"copied": len(_s(sid).share())}


@app.get("/sessions/{sid}/memories")
def memories(sid: str):
    return _s(sid).memories()


@app.post("/sessions/{sid}/forget")
def forget(sid: str, b: Forget):
    rep = _s(sid).forget(b.request, b.agent)
    return rep.model_dump(exclude={"verification"})


@app.post("/sessions/{sid}/ask")
def ask(sid: str, b: Ask):
    return _s(sid).ask(b.question, b.agent)


@app.get("/sessions/{sid}/receipts")
def receipts(sid: str):
    s = _s(sid)
    ok, idx, why = s.verify_receipts()
    return {"chain_ok": ok, "first_bad": idx, "reason": why, "receipts": s.fm.receipts.receipts}
