"""Reproduces the worked example of the project guide (section 5)."""
import json, sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from forgetme.agent import MemoryHub
from forgetme.pipeline import ForgetMe

hub = MemoryHub()
a = hub.agent("A")
a.observe("I am diabetic, I was diagnosed with type 2 diabetes.")
a.observe("I'm vegetarian, so no meat please.")
a.end_session()
print("BEFORE");  [print(" ", m.id, m.tier, m.parents, m.text) for m in hub.store.all()]
rep = ForgetMe(hub).forget("Forget that I have diabetes")
print("\nREPORT")
print(json.dumps({k: v for k, v in rep.model_dump().items() if k not in ("verification", "request_id", "cost")}, indent=1))
print("\nAFTER");   [print(" ", m.id, m.tier, m.parents, m.text) for m in hub.store.all()]
