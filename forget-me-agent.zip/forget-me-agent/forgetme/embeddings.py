"""Deterministic offline embedder (hashed words + char trigrams + concept tokens).

The concept/category tokens stand in for the *semantic* knowledge of a neural
embedding model: paraphrases and implications ("avoids sugar" ~ diabetes) land close
together, while text with no cue (a neutral depth-3 derived note) does not.
A sentence-transformers embedder is available via `make_embedder("st")`.
"""
from __future__ import annotations

import hashlib
import numpy as np

from .lexicon import CONCEPTS, INFERENCES, CATEGORY_CUES, words, concept_hits

_QV = {c.q_value.lower(): c.id for c in CONCEPTS.values() if c.q_value}
_QV.update({i.q_value.lower(): i.id for i in INFERENCES.values()})


def _h(tok: str, dim: int) -> tuple[int, float]:
    d = hashlib.blake2b(tok.encode(), digest_size=8).digest()
    v = int.from_bytes(d, "little")
    return v % dim, 1.0 if (v >> 40) & 1 else -1.0


class HashingEmbedder:
    name = "hashing-v1"

    def __init__(self, dim: int = 512):
        self.dim = dim

    def _features(self, text: str):
        ws = words(text)
        for w in ws:
            yield w, 1.0
            if len(w) > 4:
                yield "p:" + w[:5], 0.4
        for a, b in zip(ws, ws[1:]):
            yield a + "_" + b, 0.5
        low = text.lower()
        seen = set()
        for cid, strength in concept_hits(text):
            seen.add(cid)
            yield "k:" + cid, 2.5 if strength == 2 else 1.6
            yield "c:" + CONCEPTS[cid].category, 1.0
        # "semantic" knowledge: a question about a concept's value / label lands near that concept
        for cid, c in CONCEPTS.items():
            if cid not in seen and (c.label in low or low.strip() == c.q_value.lower()):
                yield "k:" + cid, 2.0
                yield "c:" + c.category, 1.0
        for iid, inf in INFERENCES.items():
            if any(a in low for a in inf.aliases) or low.strip() == inf.q_value.lower():
                yield "k:" + iid, 2.5
                yield "c:inference", 1.0
        wset = set(ws)
        for cat, cues in CATEGORY_CUES.items():
            if any(c in wset for c in cues):
                yield "c:" + cat, 0.8

    def embed(self, texts: list[str]) -> np.ndarray:
        out = np.zeros((len(texts), self.dim), dtype=np.float32)
        for i, t in enumerate(texts):
            for tok, w in self._features(t):
                j, s = _h(tok, self.dim)
                out[i, j] += s * w
            n = np.linalg.norm(out[i])
            if n > 0:
                out[i] /= n
        return out


class STEmbedder:  # optional, needs `pip install sentence-transformers`
    def __init__(self, model="paraphrase-multilingual-MiniLM-L12-v2"):
        from sentence_transformers import SentenceTransformer
        self.model = SentenceTransformer(model)
        self.dim = self.model.get_sentence_embedding_dimension()
        self.name = "st:" + model

    def embed(self, texts):
        return np.asarray(self.model.encode(texts, normalize_embeddings=True), dtype=np.float32)


def make_embedder(kind: str = "hash", **kw):
    return STEmbedder(**kw) if kind == "st" else HashingEmbedder(**kw)
