"""Baseline 3-tier memory agent + multi-agent hub (steps 1-2).

raw      : facts extracted from user turns
summary  : consolidated summaries (category + session) - these MIX facts
derived  : derived notes / inferences, in chains of depth 1..3
Every record carries id, text, tier, parents, agent_id, created_at, embedding_id.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field

from .config import ForgetConfig
from .embeddings import HashingEmbedder
from .guard import Guard, hash_features
from .lexicon import CONCEPTS, INFERENCES, FORGET_INTENT_RE, concept_hits
from .llm import OfflineBackend
from .store import Memory, MemoryStore
from .vector_index import VectorIndex


@dataclass
class Answer:
    text: str
    sources: list[int] = field(default_factory=list)
    from_cache: bool = False


class MemoryHub:
    """Shared store + index for one or more agents (the multi-agent memory)."""

    def __init__(self, backend=None, embedder=None, db_path: str = ":memory:", cfg: ForgetConfig | None = None):
        self.cfg = cfg or ForgetConfig()
        self.backend = backend or OfflineBackend()
        self.embedder = embedder or HashingEmbedder()
        self.store = MemoryStore(db_path)
        self.index = VectorIndex(self.embedder.dim)
        self.key = hashlib.sha256(f"forgetme-key-{self.cfg.seed}".encode()).digest()
        self.guard = Guard(self.key)
        self.suppressed: list[frozenset[str]] = []      # hashed signatures of inferences that must not be re-derived
        self.agents: dict[str, MemoryAgent] = {}
        self.owner: dict[int, str] = {}
        self.clock = 0.0

    def tick(self) -> float:
        self.clock += 1.0
        return self.clock

    def agent(self, agent_id: str = "A") -> "MemoryAgent":
        if agent_id not in self.agents:
            self.agents[agent_id] = MemoryAgent(self, agent_id)
        return self.agents[agent_id]

    def add_memory(self, text, tier, agent_id, parents=(), meta=None, cross_agent=False) -> Memory:
        meta = dict(meta or {})
        mid = self.store.add(text, tier, agent_id, parents, meta, created_at=self.tick(), cross_agent=cross_agent)
        if "roots" not in meta:
            self.store.update_text(mid, text, {"roots": [f"m{mid}"]})
        self.owner[mid] = agent_id
        self.index.upsert(mid, self.embedder.embed([text])[0])
        for ag in self.agents.values():        # retrieval caches are stale once the index changes
            ag.cache.clear()
        return self.store.get(mid)

    def reindex(self, mid: int):
        m = self.store.get(mid)
        if m and m.status == "live":
            self.index.upsert(mid, self.embedder.embed([m.text])[0])

    def share(self, src: str, dst: str, ids: list[int]) -> dict[int, int]:
        """Copy memories into another agent's namespace, linked by cross-agent provenance edges."""
        mapping: dict[int, int] = {}
        for i in sorted(ids):
            m = self.store.get(i)
            if m is None or m.status != "live" or m.agent_id != src:
                continue
            meta = dict(m.meta)
            meta["shared_from"] = i
            parents = [mapping[p] for p in m.parents if p in mapping]
            new = self.add_memory(m.text, m.tier, dst, parents=parents, meta=meta)
            self.store.conn.execute("INSERT OR IGNORE INTO edges VALUES(?,?,1)", (i, new.id))
            self.store.conn.commit()
            mapping[i] = new.id
        return mapping

    def is_suppressed(self, text: str) -> bool:
        if not self.suppressed:
            return False
        feats = hash_features(text, self.key)
        return any(sig & feats for sig in self.suppressed)

    def compact(self) -> dict[int, int]:
        mapping = self.store.renumber()
        self.index.renumber({i: mapping[i] for i in self.index.ids})
        self.owner = {mapping[i]: a for i, a in self.owner.items() if i in mapping}
        self.guard.renumber(mapping)
        for ag in self.agents.values():
            ag.pending = [mapping[i] for i in ag.pending if i in mapping]
            ag.cache.clear()
        return mapping


class MemoryAgent:
    def __init__(self, hub: MemoryHub, agent_id: str):
        self.hub, self.agent_id = hub, agent_id
        self.working_context: list[str] = []
        self.cache: dict[tuple[str, int], list[tuple[int, str, float, float]]] = {}
        self.pending: list[int] = []

    # ------------------------------------------------------------------ write path
    def observe(self, utterance: str, fact_id: str | None = None) -> Memory | None:
        """Ingest one user turn. Forget-request turns are never stored as facts (a competent extractor)."""
        self.working_context.append(utterance)
        self.working_context = self.working_context[-20:]
        if FORGET_INTENT_RE.search(utterance):
            return None
        direct = [cid for cid, s in concept_hits(utterance) if s == 2]
        if not direct:
            return None
        t = utterance.lower()
        cid = max(direct, key=lambda c: sum(a in t for a in CONCEPTS[c].aliases))
        c = CONCEPTS[cid]
        meta = {"concept": cid, "gist": c.gist, "event_time": c.event_time}
        if fact_id:
            meta["roots"] = [fact_id]
        mem = self.hub.add_memory(utterance, "raw", self.agent_id, meta=meta)
        self.pending.append(mem.id)
        return mem

    def end_session(self, derive_depth: int = 3):
        self.consolidate(derive_depth)
        self.working_context = []

    def _roots(self, parents: list[Memory]) -> list[str]:
        r: list[str] = []
        for p in parents:
            r += p.meta.get("roots", [])
        return sorted(set(r))

    def consolidate(self, derive_depth: int = 3):
        hub, st = self.hub, self.hub.store
        raws = [m for m in (st.get(i) for i in self.pending) if m and m.status == "live"]  # noqa
        self.pending = []
        if not raws:
            return
        by_cat: dict[str, list[Memory]] = {}
        for m in raws:
            by_cat.setdefault(CONCEPTS[m.meta["concept"]].category, []).append(m)
        for cat, ms in by_cat.items():
            if len(ms) >= 2:
                hub.add_memory(hub.backend.summarize([m.gist for m in ms]), "summary", self.agent_id,
                               parents=[m.id for m in ms], meta={"gist": None, "roots": self._roots(ms), "cat": cat})
        for i in range(0, len(raws), 4):          # session summaries: every raw fact lands in some (mixed) summary
            ms = raws[i:i + 4]
            if len(ms) >= 2 or hub.cfg.archive_raw:
                hub.add_memory(hub.backend.summarize([m.gist for m in ms]), "summary", self.agent_id,
                               parents=[m.id for m in ms], meta={"roots": self._roots(ms)})
        for m in raws:
            prev = m
            for note in CONCEPTS[m.meta["concept"]].chain[:derive_depth]:
                prev = hub.add_memory(note, "derived", self.agent_id, parents=[prev.id],
                                      meta={"gist": note, "roots": prev.meta.get("roots", [])})
        self._infer(derive_depth)
        if hub.cfg.archive_raw:                   # cold storage: still in the store (and must be erased), not retrievable
            for m in raws:
                st.set_status(m.id, "archived")
                hub.index.delete(m.id)

    def _infer(self, derive_depth: int):
        hub, st = self.hub, self.hub.store
        live_raw = {}
        for m in st.all(("live", "archived"), self.agent_id):
            if m.tier == "raw":
                live_raw.setdefault(m.meta.get("concept"), m)
        existing = {m.meta.get("inference") for m in st.all(("live",), self.agent_id) if m.meta.get("inference")}
        for iid, inf in INFERENCES.items():
            a, b = (live_raw.get(s) for s in inf.sources)
            if not a or not b or iid in existing or hub.is_suppressed(inf.text):
                continue
            roots = sorted(set(a.meta.get("roots", []) + b.meta.get("roots", []) + [iid]))
            node = hub.add_memory(inf.text, "derived", self.agent_id, parents=[a.id, b.id],
                                  meta={"gist": inf.text, "roots": roots, "inference": iid})
            prev = node
            for note in inf.chain[:max(0, derive_depth - 1)]:
                prev = hub.add_memory(note, "derived", self.agent_id, parents=[prev.id],
                                      meta={"gist": note, "roots": roots})

    # ------------------------------------------------------------------ read path
    def retrieve(self, query: str, k: int | None = None) -> list[tuple[Memory, float]]:
        hub = self.hub
        k = k or hub.cfg.retrieval_k
        key = (query, k)
        if key in self.cache:
            rows = [(Memory(id=i, text=t, tier="cached", agent_id=self.agent_id, created_at=ts), s)
                    for i, t, s, ts in self.cache[key]]
        else:
            qv = hub.embedder.embed([query])[0]
            rows = []
            for i, s in hub.index.search(qv, k=k + 30):
                if hub.owner.get(i) != self.agent_id:
                    continue
                m = hub.store.get(i)
                if m is None or m.status != "live":
                    continue
                rows.append((m, s))
            self.cache[key] = [(m.id, m.text, s, m.created_at) for m, s in rows[:k + 3]]
        if hub.cfg.use_guard:
            rows = [(m, s) for m, s in rows if hub.guard.allows(m.id, m.text, m.created_at)]
        return rows[:k]

    def answer(self, question: str, fresh: bool = True) -> Answer:
        b = self.hub.backend
        k, thr = b.answer_policy(question, self.hub.cfg.retrieval_k)
        was_cached = (question, k) in self.cache
        rows = [(m, s) for m, s in self.retrieve(question, k) if s >= thr]
        items = [(m.id, m.text, s) for m, s in rows]
        if not fresh:
            ctx = [c for c in self.working_context[-5:]
                   if not (self.hub.cfg.use_guard and self.hub.guard.text_blocked(c, 1e18))]
            items += [(None, c, 1.0) for c in ctx]
        return Answer(b.compose_answer(question, items), [m.id for m, _ in rows], was_cached)

    def tool_search(self, needle: str) -> list[Memory]:
        """Naive keyword 'search tool' over this agent's namespace (ignores status; guard still applies)."""
        out = self.hub.store.search_text(needle, self.agent_id)
        if self.hub.cfg.use_guard:
            out = [m for m in out if self.hub.guard.allows(m.id, m.text, m.created_at)]
        return out

    # ------------------------------------------------------------------ forget hooks
    def on_forget(self, ids: set[int], extra_guard: Guard | None = None) -> int:
        """Invalidate caches and scrub conversation context (multi-agent notification target)."""
        n = 0
        for key in list(self.cache):
            rows = self.cache[key]
            if any(i in ids for i, *_ in rows) or (extra_guard and any(extra_guard.text_blocked(t, 1e18) for _, t, _, _ in rows)):
                del self.cache[key]
                n += 1
        if extra_guard:
            keep = [c for c in self.working_context if not extra_guard.text_blocked(c, 1e18)]
            n += len(self.working_context) - len(keep)
            self.working_context = keep
        return n
