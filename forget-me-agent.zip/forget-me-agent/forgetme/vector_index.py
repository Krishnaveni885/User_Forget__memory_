"""Minimal vector index whose deletes are *physical* (row removed, memory zeroed).

Chroma/FAISS-style libraries often only tombstone or cannot delete at all; the project
must be able to delete individual vectors, and to prove it.
"""
from __future__ import annotations
import numpy as np


class VectorIndex:
    def __init__(self, dim: int):
        self.dim = dim
        self.ids: list[int] = []
        self.mat = np.zeros((0, dim), dtype=np.float32)
        self._pos: dict[int, int] = {}

    def __len__(self):
        return len(self.ids)

    def __contains__(self, i: int):
        return i in self._pos

    def upsert(self, i: int, vec: np.ndarray):
        vec = np.asarray(vec, dtype=np.float32).reshape(1, -1)
        if i in self._pos:
            self.mat[self._pos[i]] = vec[0]
            return
        self._pos[i] = len(self.ids)
        self.ids.append(i)
        self.mat = np.vstack([self.mat, vec])

    def delete(self, i: int) -> bool:
        p = self._pos.pop(i, None)
        if p is None:
            return False
        self.mat[p] = 0.0                      # zero before removal
        self.mat = np.delete(self.mat, p, axis=0)
        self.ids.pop(p)
        for k in range(p, len(self.ids)):
            self._pos[self.ids[k]] = k
        return True

    def renumber(self, mapping: dict[int, int]):
        self.ids = [mapping[i] for i in self.ids]
        self._pos = {i: p for p, i in enumerate(self.ids)}

    def search(self, vec: np.ndarray, k: int = 5, allowed: set[int] | None = None):
        if not self.ids:
            return []
        sims = self.mat @ np.asarray(vec, dtype=np.float32).reshape(-1)
        order = np.argsort(-sims)
        out = []
        for p in order:
            i = self.ids[p]
            if allowed is not None and i not in allowed:
                continue
            out.append((i, float(sims[p])))
            if len(out) >= k:
                break
        return out
