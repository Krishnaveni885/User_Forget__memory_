from __future__ import annotations

from pydantic import BaseModel, Field

from .lexicon import CONCEPTS, INFERENCES, CONCEPT_BY_CATEGORY


class ParsedRequest(BaseModel):
    """Structured form of a natural-language forget request (validated; malformed LLM JSON is rejected)."""
    entity: str = "user"
    kind: str = "unknown"      # factual|compositional|semantic|inferential|temporal|replacement|unknown
    attribute: str = ""        # human-readable (category / label), no raw value
    concept_ids: list[str] = Field(default_factory=list)
    inference_ids: list[str] = Field(default_factory=list)
    categories: list[str] = Field(default_factory=list)
    period: str | None = None  # YYYY-MM
    new_concept_ids: list[str] = Field(default_factory=list)
    scope: str = "all"
    codemixed: bool = False
    needs_clarification: bool = False
    clarifying_question: str | None = None


class TargetSpec(BaseModel):
    """What the finder/judge/verifier look for. Built from a ParsedRequest (or from a repair step)."""
    kind: str
    concept_ids: list[str] = Field(default_factory=list)
    inference_ids: list[str] = Field(default_factory=list)
    categories: list[str] = Field(default_factory=list)
    period: str | None = None

    @classmethod
    def from_parsed(cls, p: ParsedRequest) -> "TargetSpec":
        ids = list(p.concept_ids)
        if p.kind == "semantic":
            for cat in p.categories:
                ids += CONCEPT_BY_CATEGORY.get(cat, [])
        if p.kind == "replacement":
            ids = list(p.concept_ids)          # only the OLD value is the target
        return cls(kind=p.kind, concept_ids=sorted(set(ids)), inference_ids=list(p.inference_ids),
                   categories=list(p.categories), period=p.period)

    def alias_terms(self, include_implied: bool = False) -> list[str]:
        out: list[str] = []
        for c in self.concept_ids:
            out += CONCEPTS[c].aliases
            if include_implied:
                out += CONCEPTS[c].implied
        for i in self.inference_ids:
            out += INFERENCES[i].aliases
        return sorted({t.strip() for t in out if t.strip()})

    def labels(self) -> list[str]:
        out = [CONCEPTS[c].label for c in self.concept_ids] + [INFERENCES[i].label for i in self.inference_ids]
        return sorted(set(out))

    def primary_categories(self) -> list[str]:
        cats = {CONCEPTS[c].category for c in self.concept_ids}
        if self.inference_ids:
            cats.add("inference")
        return sorted(cats | set(self.categories))
