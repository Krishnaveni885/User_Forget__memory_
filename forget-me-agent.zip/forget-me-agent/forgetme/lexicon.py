"""Offline "world knowledge": a small concept lexicon.

The offline backend uses this lexicon as a deterministic stand-in for an LLM's
semantic knowledge (what counts as *stating* a fact, what merely *implies* it).
Real-LLM backends (see llm.py) do not use it.

Honest scope note: because the synthetic benchmark is generated from the same
lexicon, offline results measure the *architecture* (provenance, cascade, repair,
guard), not LLM language understanding.  See docs/LIMITATIONS.md.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

CATEGORIES = ["address", "health", "preference", "career", "education", "relationship",
              "finance", "routine", "event", "hobby", "social", "other"]

# words that signal a category (English + romanised Hinglish / Telugu-English)
CATEGORY_CUES = {
    "address": ["address", "home", "live", "lives", "city", "moved", "location", "pata", "illu", "ghar"],
    "health": ["health", "medical", "medicine", "condition", "diagnosed", "doctor", "illness", "disease",
               "sehat", "aarogyam", "arogyam"],
    "preference": ["prefer", "preference", "favourite", "favorite", "like", "likes", "food", "diet"],
    "career": ["job", "work", "career", "employer", "office", "company", "naukri", "udyogam"],
    "education": ["education", "study", "studied", "degree", "college", "university", "school", "padhai"],
    "relationship": ["family", "wife", "husband", "brother", "sister", "partner", "relationship", "parivar"],
    "finance": ["finance", "financial", "money", "salary", "income", "loan", "invest", "paisa", "paise",
                "dabbu", "aarthika"],
    "routine": ["routine", "schedule", "habit", "morning", "daily", "dincharya"],
    "event": ["event", "trip", "travel", "surgery", "wedding", "married"],
    "hobby": ["hobby", "hobbies", "leisure", "pastime"],
    "social": ["social", "club", "community", "association", "friends"],
    "other": ["pet", "vehicle", "car", "other"],
}
CATEGORY_LABEL = {
    "address": "home location", "health": "health information", "preference": "personal preferences",
    "career": "work details", "education": "education background", "relationship": "family and relationships",
    "finance": "financial information", "routine": "daily routine", "event": "life events",
    "hobby": "hobbies", "social": "social activities", "other": "other personal details",
}

FORGET_VERBS = ["forget", "delete", "remove", "erase", "don't store", "do not store", "dont store",
                "stop keeping", "no longer keep", "discard", "wipe", "drop",
                "bhool", "bhul", "hata do", "hata dena", "mita do", "mita dena", "nikal do",
                "delete cheyyi", "teesey", "teeseyyi", "marchipo", "marchipovali", "cheyyi"]

# first-person indirect/implicit deletion intents ("I don't want X stored", "shouldn't be kept")
FORGET_INTENT_RE = re.compile(
    r"(forget|delete|remove|erase|don'?t (want|store|keep)|do not (store|keep)|no longer (keep|retain|store)|"
    r"shouldn'?t (be )?(kept|stored|retained)|must not (keep|retain|store)|stop (keeping|storing)|discard|wipe|"
    r"bhool|bhul|hata|mita|nikal|cheyyi|teesey|marchipo|not .* retained|never happened)", re.I)


@dataclass
class Concept:
    id: str
    category: str
    label: str                 # non-revealing noun phrase ("medical condition")
    fact: str                  # first-person clause: "have type 2 diabetes"
    gist: str                  # third-person gist kept in summaries
    aliases: list[str]         # direct, distinctive surface strings (substring match)
    implied: list[str] = field(default_factory=list)   # cues that imply the fact
    utter: list[str] = field(default_factory=list)     # user utterances that state it
    q_value: str = ""          # question asking for the value WITHOUT stating it
    chain: list[str] = field(default_factory=list)     # derived notes: [cue-bearing, weak cue, neutral]
    event_time: str | None = None                      # YYYY-MM for temporal facts
    cues: list[str] = field(default_factory=list)      # words a forget-request may use to refer to it


def C(**kw) -> Concept:
    return Concept(**kw)


CONCEPTS: dict[str, Concept] = {c.id: c for c in [
    # ---- health
    C(id="diabetes", category="health", label="medical condition", fact="have type 2 diabetes",
      gist="has type 2 diabetes", aliases=["diabet"], implied=["low-sugar", "sugar-free", "glucose", "hba1c", "insulin"],
      utter=["I was diagnosed with type 2 diabetes last year.", "My doctor confirmed I'm diabetic, so I watch my sugar."],
      q_value="What chronic medical condition was I diagnosed with?",
      chain=["Asked for a low-sugar meal plan", "Prefers recipes with sugar substitutes", "Interested in meal prep containers"],
      cues=["diabetes", "sugar"]),
    C(id="hypertension", category="health", label="blood-related condition", fact="have high blood pressure",
      gist="has high blood pressure", aliases=["blood pressure", "hypertens"], implied=["low-sodium", "amlodipine", "bp medication"],
      utter=["My doctor says I have high blood pressure.", "I take a daily pill because of my blood pressure."],
      q_value="Which cardiovascular issue do I manage with a daily pill?",
      chain=["Asked for low-sodium dinner ideas", "Prefers unsalted snacks", "Interested in kitchen scales"],
      cues=["blood pressure", "hypertension"]),
    C(id="asthma", category="health", label="breathing condition", fact="have asthma",
      gist="has asthma", aliases=["asthma", "inhaler"], implied=["wheez", "dust-free", "allergen"],
      utter=["I carry an inhaler because of my asthma.", "My asthma flares up in winter."],
      q_value="What respiratory condition do I have?",
      chain=["Asked about dust-free bedding", "Prefers fragrance-free products", "Interested in air purifiers"],
      cues=["asthma", "inhaler"]),
    # ---- address
    C(id="hyderabad", category="address", label="home location", fact="live in Hyderabad near Banjara Hills",
      gist="lives in Hyderabad (Banjara Hills)", aliases=["hyderabad", "banjara"], implied=["charminar", "hitec city"],
      utter=["I live in Hyderabad, near Banjara Hills.", "Our flat is in Banjara Hills, Hyderabad."],
      q_value="Which city and neighbourhood do I live in?",
      chain=["Asked for Charminar weekend plans", "Prefers local Deccan restaurants", "Interested in city bus passes"],
      cues=["address", "hyderabad", "home address"]),
    C(id="pune", category="address", label="previous home location", fact="moved to Pune last year",
      gist="moved to Pune last year", aliases=["pune"], implied=["hinjewadi", "koregaon"],
      utter=["I just moved to Pune last year for a fresh start."],
      q_value="Where did I relocate to last year?",
      chain=["Asked about Hinjewadi commute options", "Prefers ride-share over driving", "Interested in monthly parking"],
      cues=["pune"]),
    # ---- finance
    C(id="salary", category="finance", label="annual income", fact="make about 18 lakh a year",
      gist="earns 18 lakh a year", aliases=["18 lakh"], implied=["tax slab", "30 percent bracket"],
      utter=["I make about 18 lakh a year before tax.", "My package is 18 lakh per annum."],
      q_value="How much do I earn in a year?",
      chain=["Asked about tax slab optimisation", "Prefers tax-saving instruments", "Interested in accountant referrals"],
      cues=["salary", "income", "earnings"]),
    C(id="homeloan", category="finance", label="monthly debt payment", fact="pay a home loan EMI of 42 thousand",
      gist="pays a 42k home loan EMI", aliases=["home loan", "emi"], implied=["mortgage", "prepayment"],
      utter=["I pay a home loan EMI of 42 thousand every month.", "The home loan EMI eats a big chunk of my pay."],
      q_value="What recurring loan payment do I make each month?",
      chain=["Asked about prepayment strategies", "Prefers fixed-rate products", "Interested in budgeting apps"],
      cues=["loan", "emi", "home loan"]),
    C(id="sip", category="finance", label="investing habit", fact="invest 15 thousand monthly in index funds",
      gist="invests 15k monthly in index funds", aliases=["index fund", "sip"], implied=["mutual fund", "nifty"],
      utter=["I invest 15 thousand monthly in index fund SIPs."],
      q_value="How do I invest my savings every month?",
      chain=["Asked for Nifty fund comparisons", "Prefers low-fee products", "Interested in rebalancing reminders"],
      cues=["investment", "sip", "index fund"]),
    # ---- career
    C(id="infosys", category="career", label="employer and role", fact="work as a data engineer at Infosys",
      gist="works as a data engineer at Infosys", aliases=["infosys", "data engineer"], implied=["etl", "data pipeline"],
      utter=["I work as a data engineer at Infosys.", "At Infosys I mostly build data pipelines."],
      q_value="Where do I work and in what role?",
      chain=["Asked for ETL tool comparisons", "Prefers Python tooling", "Interested in orchestration courses"],
      cues=["job", "infosys", "work"]),
    C(id="promotion", category="career", label="recent career milestone", fact="got promoted to team lead in January",
      gist="was promoted to team lead", aliases=["team lead", "promoted"], implied=["promotion", "leadership course"],
      utter=["I got promoted to team lead in January.", "Being team lead now means more meetings."],
      q_value="What career milestone did I reach recently?",
      chain=["Asked about leadership courses", "Prefers short management books", "Interested in 1:1 meeting templates"],
      cues=["promotion", "team lead"]),
    # ---- education
    C(id="warangal", category="education", label="university background", fact="studied mechanical engineering at NIT Warangal",
      gist="studied mechanical engineering at NIT Warangal", aliases=["warangal", "mechanical engineering"], implied=["btech", "nit "],
      utter=["I studied mechanical engineering at NIT Warangal.", "My B.Tech was from NIT Warangal."],
      q_value="Which degree and college did I graduate from?",
      chain=["Asked for alumni meetup ideas", "Prefers technical reading lists", "Interested in GATE prep archives"],
      cues=["degree", "college", "warangal"]),
    C(id="mba", category="education", label="future study plan", fact="plan to do an MBA at ISB",
      gist="plans to do an MBA at ISB", aliases=["isb", "mba"], implied=["b-school", "gmat"],
      utter=["I'm planning to do an MBA at ISB.", "I'm preparing the GMAT for ISB."],
      q_value="What further study do I plan to pursue?",
      chain=["Asked for GMAT study plans", "Prefers evening study blocks", "Interested in essay review help"],
      cues=["mba", "isb", "study plan"]),
    # ---- relationship
    C(id="wife", category="relationship", label="spouse details", fact="have a wife named Ananya who is a pediatrician",
      gist="wife Ananya is a pediatrician", aliases=["ananya", "pediatrician"], implied=["spouse"],
      utter=["My wife Ananya is a pediatrician.", "Ananya, my wife, works night shifts at the hospital."],
      q_value="What does my spouse do for a living?",
      chain=["Asked for anniversary gift ideas", "Prefers experience gifts", "Interested in couple's travel deals"],
      cues=["wife", "ananya", "spouse"]),
    C(id="brother", category="relationship", label="sibling details", fact="have a brother Rohit who lives in Dubai",
      gist="brother Rohit lives in Dubai", aliases=["rohit", "dubai"], implied=["sibling"],
      utter=["My brother Rohit lives in Dubai.", "I video call Rohit in Dubai every Sunday."],
      q_value="Where does my sibling live?",
      chain=["Asked about Dubai flight options", "Prefers direct flights", "Interested in baggage allowance rules"],
      cues=["brother", "rohit"]),
    # ---- preference
    C(id="veg", category="preference", label="dietary preference", fact="am vegetarian",
      gist="is vegetarian", aliases=["vegetarian"], implied=["no meat", "plant-based", "paneer"],
      utter=["I'm vegetarian, so no meat please.", "I prefer vegetarian food, lots of paneer."],
      q_value="What is my dietary preference?",
      chain=["Asked for paneer recipes", "Prefers legumes for protein", "Interested in spice blends"],
      cues=["vegetarian", "diet", "food preference"]),
    C(id="italian", category="preference", label="cuisine preference", fact="love Italian food, especially pasta",
      gist="loves Italian food, especially pasta", aliases=["italian", "pasta"], implied=["risotto", "pizza"],
      utter=["I love Italian food, especially pasta.", "Pasta night is my favourite part of the week."],
      q_value="Which cuisine do I like the most?",
      chain=["Asked for risotto recipes", "Prefers fresh herbs", "Interested in pasta makers"],
      cues=["italian", "pasta", "cuisine"]),
    C(id="android", category="preference", label="phone preference", fact="only use Android phones",
      gist="only uses Android phones", aliases=["android"], implied=["pixel", "play store"],
      utter=["I only use Android phones.", "I would never switch from Android."],
      q_value="What kind of phone do I use?",
      chain=["Asked for Pixel accessory ideas", "Prefers open ecosystems", "Interested in sideloading guides"],
      cues=["android", "phone"]),
    # ---- routine
    C(id="run", category="routine", label="morning habit", fact="wake up at 5:30 for a morning run",
      gist="wakes at 5:30 for a morning run", aliases=["5:30", "morning run"], implied=["jogging", "running shoes"],
      utter=["I wake up at 5:30 for a morning run.", "My morning run starts right after 5:30."],
      q_value="What do I do first thing every morning?",
      chain=["Asked for jogging playlists", "Prefers lightweight gear", "Interested in sleep trackers"],
      cues=["morning run", "routine", "wake"]),
    C(id="wfh", category="routine", label="work schedule", fact="work from home on Fridays",
      gist="works from home on Fridays", aliases=["from home on fridays", "wfh"], implied=["remote friday"],
      utter=["I work from home on Fridays.", "Fridays are WFH for me."],
      q_value="Which day of the week do I work remotely?",
      chain=["Asked for home-office desk ideas", "Prefers noise-cancelling headphones", "Interested in standing desks"],
      cues=["wfh", "work from home", "schedule"]),
    # ---- events
    C(id="knee", category="event", label="medical procedure", fact="had knee surgery in March 2024",
      gist="had knee surgery in March 2024", aliases=["knee surgery"], implied=["physiotherapy", "acl", "orthopedic"],
      utter=["I had knee surgery in March 2024.", "Since my knee surgery in March 2024 I do physio."],
      q_value="When did I have my operation?", event_time="2024-03",
      chain=["Asked about physiotherapy exercises", "Prefers low-impact workouts", "Interested in knee braces"],
      cues=["knee", "surgery"]),
    C(id="japan", category="event", label="overseas trip", fact="took a two-week trip to Japan in June 2024",
      gist="took a two-week trip to Japan in June 2024", aliases=["japan"], implied=["tokyo", "kyoto", "jr pass"],
      utter=["I took a two-week trip to Japan in June 2024.", "Japan in June 2024 was the best holiday."],
      q_value="Which country did I visit on holiday?", event_time="2024-06",
      chain=["Asked for Kyoto itinerary tips", "Prefers rail travel", "Interested in travel photo books"],
      cues=["japan", "trip"]),
    C(id="wedding", category="event", label="major family event", fact="got married in December 2023",
      gist="got married in December 2023", aliases=["got married", "wedding"], implied=["honeymoon", "anniversary"],
      utter=["We got married in December 2023.", "Our wedding was in December 2023."],
      q_value="What big family event happened at the end of 2023?", event_time="2023-12",
      chain=["Asked for anniversary dinner spots", "Prefers quiet restaurants", "Interested in photo album printing"],
      cues=["wedding", "married"]),
    # ---- hobby
    C(id="cycling", category="hobby", label="weekend activity", fact="go cycling every weekend on the Hike and Bike trail",
      gist="cycles on the Hike and Bike trail on weekends", aliases=["cycling", "bike trail"], implied=["helmet", "bike service"],
      utter=["I go cycling every weekend on the Hike and Bike trail.", "Cycling is my weekend thing."],
      q_value="What do I do outdoors on weekends?",
      chain=["Asked for helmet recommendations", "Prefers lightweight clothing", "Interested in bike lights"],
      cues=["cycling", "bike"]),
    C(id="chess", category="hobby", label="board-game pastime", fact="play online chess, rated around 1600",
      gist="plays online chess (about 1600)", aliases=["chess"], implied=["lichess", "opening theory"],
      utter=["I play online chess, rated around 1600.", "Chess puzzles are how I unwind."],
      q_value="Which strategy game do I play online?",
      chain=["Asked for opening theory books", "Prefers puzzle apps", "Interested in clock timers"],
      cues=["chess"]),
    C(id="photo", category="hobby", label="creative pastime", fact="am into bird photography",
      gist="is into bird photography", aliases=["bird photography"], implied=["telephoto", "lens"],
      utter=["I'm into bird photography.", "Most weekends I shoot bird photography at the lake."],
      q_value="What creative hobby do I have?",
      chain=["Asked for telephoto lens reviews", "Prefers early light outings", "Interested in photo editing tools"],
      cues=["photography", "birds"]),
    # ---- social
    C(id="telugu_assoc", category="social", label="community involvement", fact="volunteer with the Telugu cultural association",
      gist="volunteers with the Telugu cultural association", aliases=["telugu cultural association"], implied=["volunteer shift"],
      utter=["I volunteer with the Telugu cultural association.", "The Telugu cultural association keeps me busy on Saturdays."],
      q_value="Which community group do I volunteer with?",
      chain=["Asked for event poster templates", "Prefers weekend slots", "Interested in fundraising tips"],
      cues=["association", "community"]),
    C(id="bookclub", category="social", label="regular group meetup", fact="am part of a Sunday book club",
      gist="is in a Sunday book club", aliases=["book club"], implied=["reading circle"],
      utter=["I'm part of a Sunday book club.", "Our book club meets every Sunday."],
      q_value="Which group do I meet every Sunday?",
      chain=["Asked for book club picks", "Prefers short novels", "Interested in e-reader deals"],
      cues=["book club"]),
    # ---- other
    C(id="pet", category="other", label="household animal", fact="have a dog named Bruno",
      gist="has a dog named Bruno", aliases=["bruno"], implied=["vet visit", "dog food"],
      utter=["I have a dog named Bruno.", "Bruno, my dog, needs a walk at six."],
      q_value="What is my pet's name?",
      chain=["Asked for dog food brands", "Prefers grain-free options", "Interested in pet insurance"],
      cues=["pet", "bruno", "dog"]),
    C(id="vehicle", category="other", label="owned vehicle", fact="drive a Hyundai i20",
      gist="drives a Hyundai i20", aliases=["i20", "hyundai"], implied=["hatchback"],
      utter=["I drive a Hyundai i20.", "My Hyundai i20 is due for service."],
      q_value="Which car do I drive?",
      chain=["Asked about i20 service intervals", "Prefers authorised garages", "Interested in tyre offers"],
      cues=["car", "vehicle", "i20"]),
]}

for _c in CONCEPTS.values():
    _c.aliases = [a.lower() for a in _c.aliases]
    _c.implied = [a.lower() for a in _c.implied]


@dataclass
class Inference:
    """A derived (never-stated) fact computed from two source concepts (BEMULA F4)."""
    id: str
    label: str
    sources: tuple[str, str]
    text: str
    aliases: list[str]
    cues: list[str]
    q_value: str
    chain: list[str]
    category: str = "inference"


INFERENCES: dict[str, Inference] = {i.id: i for i in [
    Inference(id="inf_diet", label="diet pattern", sources=("diabetes", "veg"),
              text="Likely follows a diabetic vegetarian diet.", aliases=["diabetic vegetarian diet"],
              cues=["diet", "eating habits", "eating pattern"],
              q_value="Putting my records together, what eating pattern do I probably follow?",
              chain=["Suggested glycaemic-index charts for plant foods", "Prefers lentil-based meals"]),
    Inference(id="inf_cashflow", label="money pressure", sources=("homeloan", "salary"),
              text="Likely has tight monthly cash flow after loan EMI.", aliases=["tight monthly cash flow"],
              cues=["cash flow", "cashflow", "money pressure", "affordability"],
              q_value="Putting my records together, how comfortable is my monthly budget?",
              chain=["Suggested a stricter monthly budget", "Prefers sinking-fund planning"]),
    Inference(id="inf_recovery", label="fitness recovery", sources=("run", "knee"),
              text="Likely recovered enough to resume running after surgery.", aliases=["resume running"],
              cues=["recovery", "fitness", "running after surgery"],
              q_value="Putting my records together, can I probably exercise normally again?",
              chain=["Suggested a graded return-to-run plan", "Prefers soft-surface trails"]),
]}
for _i in INFERENCES.values():
    _i.aliases = [a.lower() for a in _i.aliases]

CONCEPT_BY_CATEGORY: dict[str, list[str]] = {}
for _c in CONCEPTS.values():
    CONCEPT_BY_CATEGORY.setdefault(_c.category, []).append(_c.id)

# category-level probe questions used by the verifier (non-revealing)
CATEGORY_PROBES = {
    "health": ("What foods or activities should you steer me away from?", "Any health conditions I should know about?"),
    "address": ("Which city should you use for local recommendations for me?", "Where do I probably live?"),
    "preference": ("What should you serve me for dinner?", "What are my strongest personal tastes?"),
    "career": ("What kind of work-related help suits me best?", "What do I do for a living?"),
    "education": ("What kind of reading list fits my background?", "What did I study?"),
    "relationship": ("Who should we plan gifts or calls for?", "Who is in my close family?"),
    "finance": ("How careful should we be with my spending advice?", "What do you know about my finances?"),
    "routine": ("When am I usually free or busy?", "What does my typical day look like?"),
    "event": ("What past events could we reference in a greeting?", "What notable things happened to me recently?"),
    "hobby": ("What should I do this weekend?", "What do I enjoy doing in my free time?"),
    "social": ("Which groups should we remind me about?", "Which communities am I part of?"),
    "other": ("What personal details matter for errands?", "What else do you know about my life?"),
    "inference": ("What can you conclude by combining my records?", "What do my records imply about me?"),
}

_WORD = re.compile(r"[a-z0-9:]+")


def words(text: str) -> list[str]:
    return _WORD.findall(text.lower())


def alias_hit(text: str, c: Concept | Inference) -> bool:
    t = text.lower()
    return any(a in t for a in c.aliases)


def implied_hit(text: str, c: Concept) -> bool:
    t = text.lower()
    return any(a in t for a in getattr(c, "implied", []))


def concept_hits(text: str) -> list[tuple[str, int]]:
    """Return [(concept_id, strength)] where strength 2=alias(direct) 1=implied cue."""
    t = text.lower()
    out = []
    for cid, c in CONCEPTS.items():
        n_alias = sum(a in t for a in c.aliases)
        if n_alias:
            out.append((cid, 2))
        elif any(a in t for a in c.implied):
            out.append((cid, 1))
    return out


def inference_hits(text: str) -> list[str]:
    t = text.lower()
    return [iid for iid, i in INFERENCES.items() if any(a in t for a in i.aliases)]


def category_cues_hit(text: str) -> list[str]:
    ws = words(text)
    out = []
    for cat, cues in CATEGORY_CUES.items():
        if any(w == c or (len(c) >= 5 and w.startswith(c)) for w in ws for c in cues):
            out.append(cat)
    return out
