"""Read-time guard (step 7).

A blocklist enforced at retrieval so a missed copy still cannot be returned. It stores NO plaintext
of the deleted fact: ids plus HMAC'd token/prefix/bigram hashes ("signatures"). A signature only
applies to memories created at or before the forget time, so a user can later restate a fact.
"""
from __future__ import annotations

import hashlib
import hmac

from .lexicon import words


def _hh(key: bytes, s: str) -> str:
    return hmac.new(key, s.encode(), hashlib.sha256).hexdigest()[:16]


def hash_features(text: str, key: bytes) -> set[str]:
    ws = words(text)
    feats: set[str] = set()
    for w in ws:
        if len(w) < 4:
            feats.add(_hh(key, w))
        else:
            for L in range(4, len(w) + 1):
                feats.add(_hh(key, w[:L]))
    for a, b in zip(ws, ws[1:]):
        feats.add(_hh(key, a + " " + b))
    return feats


def signature_of_terms(terms: list[str], key: bytes) -> set[str]:
    sig: set[str] = set()
    for t in terms:
        ws = words(t)
        if not ws:
            continue
        sig.add(_hh(key, ws[0] if len(ws) == 1 else ws[0] + " " + ws[1]))
    return sig


class Guard:
    def __init__(self, key: bytes):
        self.key = key
        self.blocked_ids: set[int] = set()
        self.signatures: list[tuple[frozenset[str], float]] = []   # (hashes, forget_time)

    def block_ids(self, ids):
        self.blocked_ids |= set(ids)

    def add_signature(self, terms: list[str], ts: float):
        sig = signature_of_terms(terms, self.key)
        if sig:
            self.signatures.append((frozenset(sig), ts))
        return sig

    def text_blocked(self, text: str, created_at: float) -> bool:
        if not self.signatures:
            return False
        feats = hash_features(text, self.key)
        return any(created_at <= ts and (sig & feats) for sig, ts in self.signatures)

    def allows(self, mem_id: int, text: str, created_at: float) -> bool:
        if mem_id in self.blocked_ids:
            return False
        return not self.text_blocked(text, created_at)

    def renumber(self, mapping: dict[int, int]):
        self.blocked_ids = {mapping.get(i, i) for i in self.blocked_ids if i in mapping}
